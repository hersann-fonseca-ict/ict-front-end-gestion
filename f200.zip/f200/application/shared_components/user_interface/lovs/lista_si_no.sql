prompt --application/shared_components/user_interface/lovs/lista_si_no
begin
--   Manifest
--     LISTA_SI_NO
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(16087362638114495)
,p_lov_name=>'LISTA_SI_NO'
,p_lov_query=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(16087672503114491)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'SI'
,p_lov_return_value=>'SI'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(16088071921114489)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'NO'
,p_lov_return_value=>'NO'
);
wwv_flow_api.component_end;
end;
/
