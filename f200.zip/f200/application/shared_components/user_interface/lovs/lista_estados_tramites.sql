prompt --application/shared_components/user_interface/lovs/lista_estados_tramites
begin
--   Manifest
--     LISTA_ESTADOS_TRAMITES
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(173483067859153628)
,p_lov_name=>'LISTA_ESTADOS_TRAMITES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ESTADOS_TRAMITES.ID_ESTADO as ID_ESTADO,',
'    ESTADOS_TRAMITES.DESCRIPCION_ESTADO as DESCRIPCION_ESTADO ',
' from ESTADOS_TRAMITES ESTADOS_TRAMITES'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_ESTADO'
,p_display_column_name=>'DESCRIPCION_ESTADO'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DESCRIPCION_ESTADO'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
