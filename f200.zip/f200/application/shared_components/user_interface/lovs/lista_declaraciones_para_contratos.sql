prompt --application/shared_components/user_interface/lovs/lista_declaraciones_para_contratos
begin
--   Manifest
--     LISTA_DECLARACIONES_PARA_CONTRATOS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(250900431712380856)
,p_lov_name=>'LISTA_DECLARACIONES_PARA_CONTRATOS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    dt.id_declaratoria,',
'    dt.id_declaratoria || '': '' || e.nombre_comercial || '' - '' || td.nombre_tipodt AS TIPO_DECLARATORIA',
'FROM declaratoria_turistica dt',
'    INNER JOIN empresa e ',
'        ON dt.id_empresa = e.id_empresa',
'    INNER JOIN tdt_solicitud tdt ',
'        ON dt.id_declaratoria = tdt.id_declaratoria',
'    INNER JOIN tipo_declaratoria td ',
'        ON tdt.id_tipodt = td.id_tipodt',
'WHERE dt.id_usuario = PKG_USUARIOS.Consulta_usuario(:APP_USER) AND td.permite_ct = ''Y'' AND dt.estadodt = 6',
'ORDER BY dt.id_declaratoria DESC;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_DECLARATORIA'
,p_display_column_name=>'TIPO_DECLARATORIA'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'ID_DECLARATORIA'
,p_default_sort_direction=>'DESC_NULLS_FIRST'
);
wwv_flow_api.component_end;
end;
/
