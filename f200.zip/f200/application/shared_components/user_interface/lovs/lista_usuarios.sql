prompt --application/shared_components/user_interface/lovs/lista_usuarios
begin
--   Manifest
--     LISTA_USUARIOS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(173482878494144833)
,p_lov_name=>'LISTA_USUARIOS'
,p_lov_query=>'select nombre, cedula from usuarios_gestion'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CEDULA'
,p_display_column_name=>'NOMBRE'
,p_default_sort_column_name=>'NOMBRE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
