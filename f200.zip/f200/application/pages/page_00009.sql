prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>unistr('Reporte Seguimiento Declaratoria Tur\00EDstica')
,p_alias=>'REPORTE-SEGUIMIENTO-DT'
,p_step_title=>unistr('Seguimiento Declaratorias y Contratos Tur\00EDstica')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240911112722'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(201887555618006407)
,p_plug_name=>unistr('Seguimiento de Declaratorias Tur\00EDsticas')
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-expanded:t-Region--accent5:t-Region--scrollBody:margin-top-sm'
,p_plug_template=>wwv_flow_api.id(24147140268830145)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(249952720253198937)
,p_plug_name=>unistr('Tabla: Seguimiento Declaratoria Tur\00EDsticas')
,p_region_name=>'reporte_dt'
,p_parent_plug_id=>wwv_flow_api.id(201887555618006407)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24162260119830139)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    e.id_empresa, ',
'    e.nombre_solicitante, ',
'    e.razon_social, ',
'    e.nombre_comercial, ',
'    e.correo, ',
'    e.telefono, ',
'    dt.id_declaratoria, ',
'    dt.id_analista, ',
'    dt.fecha_registro, ',
'    dt.estadodt ',
'FROM empresa e ',
'INNER JOIN declaratoria_turistica dt ON e.id_empresa = dt.id_empresa ',
'WHERE dt.id_usuario = PKG_USUARIOS.Consulta_usuario(:APP_USER);'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Tabla: Seguimiento Declaratoria Tur\00EDsticas')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(249952894377198938)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No se encontraron datos'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_owner=>'HERSANN.FONSECA'
,p_internal_uid=>249952894377198938
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249952947214198939)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Responder'
,p_column_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::P10_ID_DECLARATORIA,P10_ID_ANALISTA,P10_NOMBRE_COMERCIAL:#ID_DECLARATORIA#,#ID_ANALISTA#,#NOMBRE_COMERCIAL#'
,p_column_linktext=>'<span class="fa fa-envelope-o" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953078944198940)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Solicitante'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953188790198941)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('Raz\00F3n Social')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953297528198942)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953314487198943)
,p_db_column_name=>'CORREO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953489789198944)
,p_db_column_name=>'TELEFONO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Tel\00E9fono')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953572097198945)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'ID Declaratoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953683180198946)
,p_db_column_name=>'ID_ANALISTA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Id Analista'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953776633198947)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(249953858918198948)
,p_db_column_name=>'ESTADODT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Estado del Tr\00E1mite')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(173483067859153628)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(250023833089358506)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2500239'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_EMPRESA:NOMBRE_SOLICITANTE:RAZON_SOCIAL:NOMBRE_COMERCIAL:CORREO:TELEFONO:ID_DECLARATORIA:ID_ANALISTA:FECHA_REGISTRO:ESTADODT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(201887777136006409)
,p_plug_name=>unistr('Seguimiento de Contratos Tur\00EDsticos')
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-expanded:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24147140268830145)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(249953904465198949)
,p_plug_name=>unistr('Tabla: Seguimiento Contratos Tur\00EDsticos')
,p_region_name=>'reporte_ct'
,p_parent_plug_id=>wwv_flow_api.id(201887777136006409)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24162260119830139)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    e.id_empresa , ',
'	e.nombre_solicitante, ',
'	e.razon_social, ',
'	e.nombre_comercial, ',
'	e.correo, e.telefono, ',
'    ct.id_contrato,',
'	dt.id_declaratoria,',
'	ct.id_analista, ',
'	ct.fecha_registro, ',
'	ct.estadoct',
'FROM empresa e',
'INNER JOIN declaratoria_turistica dt ON dt.id_empresa = e.id_empresa ',
'INNER JOIN contrato_turistico ct ON ct.id_declaratoria = dt.id_declaratoria',
'WHERE ct.id_usuario = PKG_USUARIOS.Consulta_usuario(:APP_USER);'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Tabla: Seguimiento Contratos Tur\00EDsticos')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(249954086180198950)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No se encontraron datos'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_owner=>'HERSANN.FONSECA'
,p_internal_uid=>249954086180198950
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250033809679469801)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Responder'
,p_column_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::P12_ID_DECLARATORIA,P12_ID_ANALISTA,P12_NOMBRE_COMERCIAL,P12_ID_CONTRATO:#ID_DECLARATORIA#,#ID_ANALISTA#,#NOMBRE_COMERCIAL#,#ID_CONTRATO#'
,p_column_linktext=>'<span class="fa fa-envelope-o" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250033998911469802)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Solicitante'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034003569469803)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('Raz\00F3n Social')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034176364469804)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034206863469805)
,p_db_column_name=>'CORREO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034339818469806)
,p_db_column_name=>'TELEFONO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Tel\00E9fono')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034888433469811)
,p_db_column_name=>'ID_CONTRATO'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>'Id Contrato'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034491341469807)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'ID Declaratoria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034607882469809)
,p_db_column_name=>'ID_ANALISTA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Id Analista'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034502489469808)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Fecha Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(250034953816469812)
,p_db_column_name=>'ESTADOCT'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>unistr('Estado del Tr\00E1mite')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_api.id(173483067859153628)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(250046690531478031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2500467'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_EMPRESA:NOMBRE_SOLICITANTE:RAZON_SOCIAL:NOMBRE_COMERCIAL:CORREO:TELEFONO:ID_DECLARATORIA:FECHA_REGISTRO:ID_ANALISTA:ID_CONTRATO:ESTADOCT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(212741707956199006)
,p_plug_name=>'Seguimiento de solicitudes'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
'<center><h3>Seguimiento a sus solicitudes</h3></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(250035511533469818)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(249952720253198937)
,p_button_name=>'BTN_REFRESCAR_TABLA_DT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--iconLeft:t-Button--hoverIconSpin:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_image_alt=>'Refrescar'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(250036153178469824)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(249953904465198949)
,p_button_name=>'BTN_REFRESCAR_TABLA_CT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--iconLeft:t-Button--hoverIconSpin:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_image_alt=>'Refrescar'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250035620628469819)
,p_name=>'DAC_REFRESCAR_TABLA_DT'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(250035511533469818)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250035775677469820)
,p_event_id=>wwv_flow_api.id(250035620628469819)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("reporte_dt").refresh();'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250036232741469825)
,p_name=>'DAC_REFRESCAR_TABLA_CT'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(250036153178469824)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250036384835469826)
,p_event_id=>wwv_flow_api.id(250036232741469825)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("reporte_ct").refresh();'
);
wwv_flow_api.component_end;
end;
/
