prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>unistr('Reporte Seguimiento Declaratoria Tur\00EDstica')
,p_alias=>'REPORTE-SEGUIMIENTO-DT'
,p_step_title=>unistr('Reporte Seguimiento Declaratoria Tur\00EDstica')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240909110044'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(173175447386417669)
,p_plug_name=>'SeguimientoDT'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24162260119830139)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT empresa.id_empresa , empresa.nombre_solicitante, empresa.razon_social, empresa.nombre_comercial, empresa.correo, empresa.telefono, declaratoria_turistica.id_declaratoria , declaratoria_turistica.fecha_registro, ',
'declaratoria_turistica.id_analista, declaratoria_turistica.estadodt, ''Responder'' responder',
'FROM empresa',
'   JOIN declaratoria_turistica ON empresa.id_empresa = declaratoria_turistica.id_empresa ',
'   WHERE empresa.cedula_solicitante = :APP_USER',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'SeguimientoDT'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(173175838199417669)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,:P10_ID_EMPRESA,P10_ID_DECLARATORIA:\#ID_EMPRESA#\,\#ID_DECLARATORIA#\'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_detail_link_condition_type=>'NEVER'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>173175838199417669
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180092482725222101)
,p_db_column_name=>'RESPONDER'
,p_display_order=>10
,p_column_identifier=>'K'
,p_column_label=>'Responder'
,p_column_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::P10_ID_ANALISTA,P10_ID_DECLARATORIA,P10_NOMBRE_COMERCIAL:#ID_ANALISTA#,#ID_DECLARATORIA#,#NOMBRE_COMERCIAL#'
,p_column_linktext=>'<img src="#APP_IMAGES#respuesta1/respuesta1.png" class="apex-edit-page" alt="">'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173175978261417673)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Id Empresa'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>':ESTADODT'
,p_display_condition2=>'4'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173178393237417675)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Id Declaratoria'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173176348264417674)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Nombre Solicitante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173176718110417674)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173177104615417675)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173177517381417675)
,p_db_column_name=>'CORREO'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173177972488417675)
,p_db_column_name=>'TELEFONO'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>unistr('Tel\00E9fono')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173178780268417675)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Fecha Registro Declaratoria'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173179112873417676)
,p_db_column_name=>'ID_ANALISTA'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Analista Asignado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173179587642417676)
,p_db_column_name=>'ESTADODT'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>unistr('Estado del Tr\00E1mite')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_api.id(173483067859153628)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(173182200945423951)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1731823'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RESPONDER:NOMBRE_SOLICITANTE:RAZON_SOCIAL:NOMBRE_COMERCIAL:CORREO:TELEFONO:FECHA_REGISTRO:ID_ANALISTA:ESTADODT:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(173491357371460643)
,p_plug_name=>'SeguimientoCT'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24162260119830139)
,p_plug_display_sequence=>60
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT e.id_empresa , e.nombre_solicitante, e.razon_social, e.nombre_comercial, e.correo, e.telefono, dt.id_declaratoria , ',
' ct.id_contrato , ct.fecha_registro,  ct.id_analista, ct.estadoct, ''Responder'' responder',
'FROM empresa e, declaratoria_turistica dt, contrato_turistico ct',
'   WHERE e.id_empresa = dt.id_empresa ',
'    and ct.ID_DECLARATORIA = dt.id_declaratoria',
'    and ct.ID_USUARIO = :APP_USER',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'SeguimientoCT'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(173491469724460644)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,:P10_ID_EMPRESA,P10_ID_DECLARATORIA:\#ID_EMPRESA#\,\#ID_DECLARATORIA#\'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_detail_link_condition_type=>'NEVER'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>173491469724460644
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(201887341649006405)
,p_db_column_name=>'RESPONDER'
,p_display_order=>10
,p_column_identifier=>'K'
,p_column_label=>'Responder'
,p_column_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::P12_ID_ANALISTA,P12_ID_CONTRATO,P12_NOMBRE_COMERCIAL:#ID_ANALISTA#,#ID_CONTRATO#,#NOMBRE_COMERCIAL#'
,p_column_linktext=>'<img src="#APP_IMAGES#respuesta1/respuesta1.png" class="apex-edit-page" alt="">'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173491527647460645)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Id Empresa'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>':ESTADODT'
,p_display_condition2=>'4'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173491632220460646)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Nombre Solicitante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173491701678460647)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173491851559460648)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173491965047460649)
,p_db_column_name=>'CORREO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173492023110460650)
,p_db_column_name=>'TELEFONO'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>unistr('Tel\00E9fono')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(201886939421006401)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Id Declaratoria'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(201887085191006402)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Fecha Registro Contrato'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(201888332026006415)
,p_db_column_name=>'ID_CONTRATO'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>'Id Contrato'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(201888490103006416)
,p_db_column_name=>'ESTADOCT'
,p_display_order=>110
,p_column_identifier=>'M'
,p_column_label=>unistr('Estado del Tr\00E1mite')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_api.id(173483067859153628)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(201889613334006428)
,p_db_column_name=>'ID_ANALISTA'
,p_display_order=>120
,p_column_identifier=>'N'
,p_column_label=>'Id Analista'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(201896360601015592)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2018964'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RESPONDER:NOMBRE_SOLICITANTE:RAZON_SOCIAL:NOMBRE_COMERCIAL:CORREO:TELEFONO:FECHA_REGISTRO:ESTADOCT::ID_ANALISTA'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(201887555618006407)
,p_plug_name=>unistr('Seguimiento de Declaratorias Tur\00EDsticas')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(201887777136006409)
,p_plug_name=>unistr('Seguimiento de Contratos Tur\00EDsticos')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--accent5:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(212741707956199006)
,p_plug_name=>'Seguimiento de solicitudes'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
'<center><h3>Seguimiento a sus solicitudes</h3></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(173180666259417687)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(173175447386417669)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(173181148534417687)
,p_event_id=>wwv_flow_api.id(173180666259417687)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(173175447386417669)
);
wwv_flow_api.component_end;
end;
/
