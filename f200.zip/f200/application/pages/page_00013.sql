prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>13
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>unistr('Form: Detalles Declaratoria Tur\00EDstica')
,p_alias=>'FORM-DETALLES-DECLARATORIA-T'
,p_step_title=>unistr('Detalles Declaratoria Tur\00EDstica')
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Registro de datos para la solicitud de Declaratoria Tur\00EDstica</h3></center>')))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#P13_CANTIDAD_COLABORADORES").keypress(function(event){ ',
'    event = (event) ? event : window.event;',
'    var charCode = (event.which) ? event.which : event.keyCode;',
'    if (charCode > 31 && (charCode < 48 || charCode > 57)) {',
'       return false;',
'    }',
'    return true;',
'});',
'',
'$("#P13_MONTO_INVERSION").keypress(function(event){ ',
'    event = (event) ? event : window.event;',
'    if ( event.which != 0 && (event.which < 48 || event.which > 57) && (event.which != 46 || $(this).val().indexOf(''.'') != -1)){    ',
'       return false;',
'    }',
'    return true;',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240919124405'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(247994962972937622)
,p_plug_name=>'Detalles de la Declaratoria'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(24174565993830135)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(247990643155937604)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(24203433356830125)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Registro de datos para la solicitud de Declaratoria Tur\00EDstica</h3></center>')))
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(247524041094690427)
,p_plug_name=>'Respaldo Legal'
,p_parent_plug_id=>wwv_flow_api.id(247994962972937622)
,p_icon_css_classes=>'fa-info-circle-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:margin-top-md'
,p_plug_template=>wwv_flow_api.id(24133046783830151)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>&nbsp;</p>',
'<p><strong>Nota:</strong> Todos los datos son obligatorios<br/><strong>Respaldo legal:</strong> Publicado en el Decreto Ejecutivo N&deg; 41370- MEIC- TUR del 07 de diciembre del 2018</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(262561601681401360)
,p_plug_name=>'Detalles de la declaratoria'
,p_parent_plug_id=>wwv_flow_api.id(247994962972937622)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24136964380830149)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_DECLARATORIA,',
'       ID_USUARIO,',
'       ID_EMPRESA,',
'       CANTIDAD_COLABORADORES,',
'       MONTO_INVERSION,',
'       ESTADODT',
'  from DECLARATORIA_TURISTICA'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(247996777517937623)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(247994962972937622)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(247997052941937623)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(247994962972937622)
,p_button_name=>'SIGUIENTE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_button_condition=>'P13_ID_EMPRESA'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(247998466749937624)
,p_branch_name=>'Go To Page 14'
,p_branch_action=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::P14_ID_DECLARATORIA:&P13_ID_DECLARATORIA.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(247997052941937623)
,p_branch_sequence=>20
,p_branch_condition_type=>'ITEM_IS_NOT_NULL'
,p_branch_condition=>'P13_ID_DECLARATORIA'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248212967270197772)
,p_name=>'P13_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_item_source_plug_id=>wwv_flow_api.id(262561601681401360)
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248213702137197777)
,p_name=>'P13_CANTIDAD_COLABORADORES'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_item_source_plug_id=>wwv_flow_api.id(262561601681401360)
,p_prompt=>'Cantidad Colaboradores'
,p_source=>'CANTIDAD_COLABORADORES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'1'
,p_attribute_03=>'left'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248214190992197777)
,p_name=>'P13_MONEDA'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Colones;Colones,D\00F3lares;Dolares')
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248214530163197778)
,p_name=>'P13_MONTO_INVERSION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_item_source_plug_id=>wwv_flow_api.id(262561601681401360)
,p_prompt=>unistr('Monto Inversi\00F3n')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>'MONTO_INVERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248214989908197779)
,p_name=>'P13_SOLICITUD'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_prompt=>' Solicitud declaratoria firmada'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_cMaxlength=>9000000
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248215310312197780)
,p_name=>'P13_DESCRIPCION'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Descripci\00F3n del proyecto')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_cMaxlength=>9000000
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'table'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248215704435197780)
,p_name=>'P13_ESTADODT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_item_source_plug_id=>wwv_flow_api.id(262561601681401360)
,p_source=>'ESTADODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248216178936197780)
,p_name=>'P13_OPERACION'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_prompt=>unistr('Operaci\00F3n')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC:En Operaci\00F3n;1,En Proyecto;2')
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248216521301197781)
,p_name=>'P13_PERMISO_SALUD'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_prompt=>'Permiso Salud'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>9000000
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248216980909197781)
,p_name=>'P13_PATENTE_MUNICIPAL'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_prompt=>'Patente Municipal'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>9000000
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248217307829197782)
,p_name=>'P13_CRONOGRAMA'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_prompt=>unistr('Cronograma de Construcci\00F3n')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>9000000
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248229404835592820)
,p_name=>'P13_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(262561601681401360)
,p_item_source_plug_id=>wwv_flow_api.id(262561601681401360)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248240204959708136)
,p_validation_name=>'VALIDAR_CANT_COLABORADORES_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P13_CANTIDAD_COLABORADORES'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Debe ingresar una cantidad v\00E1lida')
,p_always_execute=>'Y'
,p_validation_condition=>'P7_CANTIDAD_COLABORADORES'
,p_validation_condition_type=>'ITEM_IS_NULL_OR_ZERO'
,p_when_button_pressed=>wwv_flow_api.id(247997052941937623)
,p_associated_item=>wwv_flow_api.id(248213702137197777)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(249300770253525931)
,p_validation_name=>'VALIDAR_SOLICITUD_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P13_SOLICITUD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe adjuntar la solicitud de la declaratoria debidamente firmada'
,p_always_execute=>'Y'
,p_validation_condition=>'NULL'
,p_validation_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_when_button_pressed=>wwv_flow_api.id(247997052941937623)
,p_associated_item=>wwv_flow_api.id(248214989908197779)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(249300850626525932)
,p_validation_name=>'VALIDAR_DESCRIPCION_NOT_NULL'
,p_validation_sequence=>30
,p_validation=>'P13_DESCRIPCION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe adjuntar la descripci\00F3n del proyecto')
,p_always_execute=>'Y'
,p_validation_condition=>'NULL'
,p_validation_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_when_button_pressed=>wwv_flow_api.id(247997052941937623)
,p_associated_item=>wwv_flow_api.id(248215310312197780)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(249300906147525933)
,p_validation_name=>'VALIDAR_OPERACION_NOT_NULL'
,p_validation_sequence=>40
,p_validation=>'P13_OPERACION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un tipo de operaci\00F3n')
,p_always_execute=>'Y'
,p_validation_condition=>'NULL'
,p_validation_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_when_button_pressed=>wwv_flow_api.id(247997052941937623)
,p_associated_item=>wwv_flow_api.id(248216178936197780)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248240812616711997)
,p_validation_name=>'VALIDAR_MONTO_INVERSION_NOT_NULL'
,p_validation_sequence=>60
,p_validation=>'P13_MONTO_INVERSION'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Debe ingresar un monto de inversi\00F3n v\00E1lido')
,p_always_execute=>'Y'
,p_validation_condition=>'P13_MONTO_INVERSION'
,p_validation_condition_type=>'ITEM_IS_NULL_OR_ZERO'
,p_when_button_pressed=>wwv_flow_api.id(247997052941937623)
,p_associated_item=>wwv_flow_api.id(248214530163197778)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248223783241251397)
,p_name=>'DAC_EN_OPERACION'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_OPERACION'
,p_condition_element=>'P13_OPERACION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248224193758251401)
,p_event_id=>wwv_flow_api.id(248223783241251397)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_PERMISO_SALUD,P13_PATENTE_MUNICIPAL'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248224601999251402)
,p_event_id=>wwv_flow_api.id(248223783241251397)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_PERMISO_SALUD,P13_PATENTE_MUNICIPAL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248225004293253852)
,p_name=>'DAC_EN_PROYECTO'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_OPERACION'
,p_condition_element=>'P13_OPERACION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248225482409253852)
,p_event_id=>wwv_flow_api.id(248225004293253852)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_CRONOGRAMA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248225969990253853)
,p_event_id=>wwv_flow_api.id(248225004293253852)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P13_CRONOGRAMA'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248227759965304300)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_DT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    vMensaje_Retorno VARCHAR2(355) := null;',
'    vRetorno boolean := true;',
'',
'    vsolicitud BLOB;',
'    vTipoArchivo_S VARCHAR2(255);',
'    vNombreArchivo_S VARCHAR2(255);',
'    vDescripcion BLOB;',
'    vTipoArchivo_D VARCHAR2(255);',
'    vNombreArchivo_D VARCHAR2(255);',
'',
'    vPermiso_salud BLOB;',
'    vTipoArchivo_PS VARCHAR2(255);',
'    vNombreArchivo_PS VARCHAR2(255);',
'    vPatente_municipal BLOB;',
'    vTipoArchivo_PM VARCHAR2(255);',
'    vNombreArchivo_PM VARCHAR2(255);',
'    vCronograma BLOB;',
'    vTipoArchivo_C VARCHAR2(255);',
'    vNombreArchivo_C VARCHAR2(255);',
'    prueba VARCHAR2(300);',
'',
'    vUser VARCHAR2(255);',
'',
'begin',
'',
'    vUser := PKG_USUARIOS.Consulta_usuario(:APP_USER);',
'',
'    -- VALIDAMOS LA EMPRESA E INSERTAMOS LA DECLARATORIA',
'	if :P13_ID_EMPRESA is not null   then',
'        if :P13_SOLICITUD is not null    then',
'            if :P13_DESCRIPCION is not null then',
'                SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vsolicitud, vTipoArchivo_S, vNombreArchivo_S FROM APEX_APPLICATION_TEMP_FILES',
'                             WHERE NAME = :P13_SOLICITUD;',
'							 ',
'                SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vDescripcion, vTipoArchivo_D, vNombreArchivo_D FROM APEX_APPLICATION_TEMP_FILES',
'                             WHERE NAME = :P13_DESCRIPCION;',
'',
'                :P13_ID_DECLARATORIA := PKG_DECLARATORIA.Insertar_Declaratoria(vUser, :P13_ID_EMPRESA, :P13_CANTIDAD_COLABORADORES, :P13_MONEDA, :P13_MONTO_INVERSION, ',
'                                                      vsolicitud, vTipoArchivo_S, vNombreArchivo_S, vDescripcion, vTipoArchivo_D, vNombreArchivo_D, vMensaje_Retorno, vRetorno);',
'            end if;',
'		end if;',
'        ',
'        ',
'		-- VALIDAMOS  LA DECLARATORIA E INSERTAMOS EL TIPO DE DT',
'		if :P13_ID_DECLARATORIA is not null then',
'			if :P13_PERMISO_SALUD is not null then --and :P13_PATENTE_MUNICIPAL is not NULL',
'				if :P13_PATENTE_MUNICIPAL is not null then',
'					SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vPermiso_salud, vTipoArchivo_PS, vNombreArchivo_PS FROM APEX_APPLICATION_TEMP_FILES',
'						 WHERE NAME = :P13_PERMISO_SALUD;',
'			',
'					SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vPatente_municipal,vTipoArchivo_PM,vNombreArchivo_PM FROM APEX_APPLICATION_TEMP_FILES',
'						 WHERE NAME = :P13_PATENTE_MUNICIPAL;',
'',
'					PKG_DECLARATORIA.Insertar_Operacion(:P13_OPERACION, vPermiso_salud, NULL, vPatente_municipal, :P13_ID_DECLARATORIA,',
'						 vTipoArchivo_PS, NULL, vTipoArchivo_PM, vNombreArchivo_PS, NULL, vNombreArchivo_PM, vMensaje_Retorno, vRetorno);',
'				end if;',
'			end if;',
'',
'			if :P13_CRONOGRAMA is not null then',
'					SELECT BLOB_CONTENT, MIME_TYPE,FILENAME INTO vCronograma, vTipoArchivo_C, vNombreArchivo_C FROM APEX_APPLICATION_TEMP_FILES',
'						 WHERE NAME = :P13_CRONOGRAMA;',
'					',
'					PKG_DECLARATORIA.Insertar_Operacion(:P13_OPERACION, NULL, vCronograma, NULL, :P13_ID_DECLARATORIA,',
'						 NULL, vTipoArchivo_C, NULL, NULL, vNombreArchivo_C, NULL, vMensaje_Retorno, vRetorno);',
'			end if;',
'		end if;',
'     end if;',
'end;'))
,p_process_error_message=>'Error al guardar los datos de la declaratoria, si el error persiste contacte al administrador del sistema.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(247997052941937623)
,p_process_success_message=>unistr('Datos de la declataroria fueron guardados con \00E9xito')
);
wwv_flow_api.component_end;
end;
/
