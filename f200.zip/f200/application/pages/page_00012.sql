prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>unistr('Modal: Respuesta Contrato Tur\00EDstico')
,p_alias=>'MODAL-RESP-CONTRATO-TURISTICO'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Respuesta Contrato Tur\00EDstico')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>wwv_flow_api.id(24114060378830160)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241010084918'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(376507511404787928)
,p_plug_name=>unistr('Respuesta a la notificaci\00F3n')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24136760250830149)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT e.id_empresa , e.nombre_solicitante, e.razon_social, e.nombre_comercial, e.correo, e.telefono, dt.id_declaratoria , ',
' ct.id_contrato , ct.fecha_registro,  ct.id_analista, ct.estadoct',
'FROM empresa e, declaratoria_turistica dt, contrato_turistico ct',
'   WHERE e.id_empresa = dt.id_empresa ',
'    and ct.ID_DECLARATORIA = dt.id_declaratoria',
'    and ct.ID_USUARIO = :APP_USER',
'  '))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(376511249972787941)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24137721610830149)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(203341489229370272)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(376511249972787941)
,p_button_name=>'BTN_CERRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(203341048295370273)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(376511249972787941)
,p_button_name=>'BTN_ENVIAR_MSJ'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Mensaje'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201888964483006421)
,p_name=>'P12_NOMBRE_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201889014725006422)
,p_name=>'P12_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201889188864006423)
,p_name=>'P12_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201889245880006424)
,p_name=>'P12_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201889366710006425)
,p_name=>'P12_ID_CONTRATO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'ID_CONTRATO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201889463850006426)
,p_name=>'P12_ESTADOCT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'ESTADOCT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201889731676006429)
,p_name=>'P12_ID_ANALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(203342594088370270)
,p_name=>'P12_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(203342989619370267)
,p_name=>'P12_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(203343369518370267)
,p_name=>'P12_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(203343766721370266)
,p_name=>'P12_FECHA_REGISTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_item_source_plug_id=>wwv_flow_api.id(376507511404787928)
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(203344517274370266)
,p_name=>'P12_NOTA'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_prompt=>'Seleccione el archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(203344982597370266)
,p_name=>'P12_CUERPO_CORREO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(376507511404787928)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Ingrese el texto del mensaje:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(249901254195610217)
,p_validation_name=>'VALIDAR_NOTA_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P12_NOTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe adjuntar un archivo'
,p_always_execute=>'Y'
,p_validation_condition=>'NULL'
,p_validation_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_when_button_pressed=>wwv_flow_api.id(203341048295370273)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(249931763024989411)
,p_validation_name=>'VALIDAR_ID_ANALISTA_NOT_NULL'
,p_validation_sequence=>30
,p_validation=>'P12_ID_ANALISTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('No se puede enviar el mensaje. El contrato tur\00EDstico a\00FAn no ha sido asignado a un analista')
,p_always_execute=>'Y'
,p_validation_condition=>'NULL'
,p_validation_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_when_button_pressed=>wwv_flow_api.id(203341048295370273)
,p_associated_item=>wwv_flow_api.id(203344982597370266)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(203348797619370245)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(203341489229370272)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(203349223948370244)
,p_event_id=>wwv_flow_api.id(203348797619370245)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(203348318910370246)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ENVIAR_MSJ'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'	vArchivo BLOB;',
'	vTipoArchivo VARCHAR2(255);',
'	vNombreArchivo VARCHAR2(255);',
'	vMensaje_Retorno VARCHAR2(355);',
'	vRetorno boolean;',
'	vEstado NUMBER:= 8;',
'	vCorreo VARCHAR2(60);',
'	vCuerpoCorreo VARCHAR2(3500);',
'	vid_secuencia NUMBER;',
'    vUser VARCHAR2(255);',
'',
'begin',
'',
'    vUser := PKG_USUARIOS.Consulta_usuario(:APP_USER);',
'',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES ',
'	WHERE NAME = :P12_NOTA;',
'	',
'	vid_secuencia := SEQ_ID_ANOTACIONES.nextval;',
'    ',
'    PKG_DECLARATORIA.Insertar_Anotacion(TO_CHAR(vid_secuencia), vArchivo, vTipoArchivo, vNombreArchivo, vUser, :P12_ID_DECLARATORIA, :P12_ID_CONTRATO, vMensaje_Retorno, vRetorno);',
'                                        ',
'    vCorreo := PKG_USUARIOS.Consulta_correo(:P12_ID_ANALISTA);',
'	',
unistr('	vCuerpoCorreo := ''La empresa '' || :P12_NOMBRE_COMERCIAL || '' la cual tiene el expediente de Contrato Tur\00EDstico '' || :P12_ID_CONTRATO || '' ha respondido la notificaci\00F3n. Y ha respondido: "'' || :P12_CUERPO_CORREO || ''"'';'),
'	',
'	PKG_CORREOS.envio_correo_adjun(vCorreo, ''Respuesta de la empresa'' , vCuerpoCorreo , TO_CHAR(vid_secuencia));',
'',
'	PKG_Contrato.Actualizar_Estado(:P12_ID_CONTRATO, vEstado);',
'    ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(203341048295370273)
,p_process_success_message=>unistr('Respuesta enviada con \00E9xito')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(203347999318370246)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'BTN_ENVIAR_MSJ'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(203345711229370266)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(376507511404787928)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form RespuestaDT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
