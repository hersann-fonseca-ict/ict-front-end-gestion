prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>'RegistroDT'
,p_alias=>'REGISTRODT'
,p_step_title=>unistr('Solicitud de Declaratoria Tur\00EDstica')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240902102549'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11648587676192639)
,p_plug_name=>unistr('Solicitud de Declaratoria Tur\00EDstica')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Registro de datos para la solicitud de Declaratoria Tur\00EDstica</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11648603180192640)
,p_plug_name=>'Datos'
,p_parent_plug_id=>wwv_flow_api.id(11648587676192639)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11648756283192641)
,p_plug_name=>'Datos de la Empresa'
,p_parent_plug_id=>wwv_flow_api.id(11648603180192640)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'EMPRESA'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14349328061203602)
,p_plug_name=>'Detalles para la declaratoria'
,p_parent_plug_id=>wwv_flow_api.id(11648756283192641)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_DECLARATORIA,',
'       ID_USUARIO,',
'       ID_EMPRESA,',
'       CANTIDAD_COLABORADORES,',
'       MONTO_INVERSION,',
'       ESTADODT',
'  from DECLARATORIA_TURISTICA'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14350347073203612)
,p_plug_name=>'Tipos de Declaratoria'
,p_parent_plug_id=>wwv_flow_api.id(11648603180192640)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_column=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P7_ID_DECLARATORIA'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14351533619203624)
,p_plug_name=>'Tipo Hospedaje'
,p_region_name=>'Tipo_Hospedaje'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14352250579203631)
,p_plug_name=>unistr('Tipo Gastronim\00EDa')
,p_region_name=>'Tipo_Gastronomia'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(14354016296203649)
,p_plug_name=>unistr('Transporte Acu\00E1tico')
,p_region_name=>'Transporte_acuatico'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(15764073264671709)
,p_plug_name=>unistr('Actividades Tem\00E1ticas')
,p_region_name=>'act_tematicas'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16241016330241146)
,p_plug_name=>'Agencia Viajes'
,p_region_name=>'agencia_viajes'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16241340911241149)
,p_plug_name=>'Lineas Aereas'
,p_region_name=>'lineas_aereas'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17195201735493903)
,p_plug_name=>'Marina'
,p_region_name=>'marina'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17195658768493907)
,p_plug_name=>'Rent a Car'
,p_region_name=>'rent_car'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>90
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17199492747493945)
,p_plug_name=>'Transporte Terrestre'
,p_region_name=>'Transporte_terrestre'
,p_parent_plug_id=>wwv_flow_api.id(14350347073203612)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>100
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(223129662349475507)
,p_plug_name=>'Apoderados Legal'
,p_region_name=>'DE_ID'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size720x480'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ROWID,',
'       ID_APODERADO,',
'       NOMBRE_APODERADO,',
'       TIPO_IDENTIFCACION,',
'       IDENTIFICACION,',
'       ID_EMPRESA',
'  from APODERADO_LEGAL',
'  WHERE ID_EMPRESA = :P7_ID_EMPRESA;'))
,p_plug_source_type=>'NATIVE_IG'
,p_translate_title=>'N'
,p_ajax_items_to_submit=>'P7_ID_EMPRESA'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'ApoderadosLegal'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(223129845557475509)
,p_name=>'ID_APODERADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID_APODERADO'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'pk_apoderado'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_default_type=>'PLSQL_FUNCTION_BODY'
,p_default_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId NUMBER;',
'BEGIN',
'    vId := SEQ_ID_APODERADOS.NEXTVAL;',
'    RETURN vId;',
'END;'))
,p_duplicate_value=>false
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(223129924651475510)
,p_name=>'NOMBRE_APODERADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NOMBRE_APODERADO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Nombre Apoderado'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>30
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(223130061918475511)
,p_name=>'TIPO_IDENTIFCACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO_IDENTIFCACION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Tipo Identifcacion'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'STATIC'
,p_lov_source=>unistr('STATIC:F\00EDsica;F\00EDsica,Jur\00EDdica;Jur\00EDdica')
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(223130179849475512)
,p_name=>'IDENTIFICACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDENTIFICACION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Identificacion'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>30
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(223130242880475513)
,p_name=>'ID_EMPRESA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID_EMPRESA'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Empresa'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P7_ID_EMPRESA'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(226797349918793206)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(226797487196793207)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_api.create_region_column(
 p_id=>wwv_flow_api.id(226798029363793213)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_api.create_interactive_grid(
 p_id=>wwv_flow_api.id(223129773470475508)
,p_internal_uid=>223129773470475508
,p_is_editable=>true
,p_edit_operations=>'i'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_api.create_ig_report(
 p_id=>wwv_flow_api.id(223138687638409591)
,p_interactive_grid_id=>wwv_flow_api.id(223129773470475508)
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_api.create_ig_report_view(
 p_id=>wwv_flow_api.id(223138720936409591)
,p_report_id=>wwv_flow_api.id(223138687638409591)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(223139209146409589)
,p_view_id=>wwv_flow_api.id(223138720936409591)
,p_display_seq=>1
,p_column_id=>wwv_flow_api.id(223129845557475509)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(223139771327409586)
,p_view_id=>wwv_flow_api.id(223138720936409591)
,p_display_seq=>2
,p_column_id=>wwv_flow_api.id(223129924651475510)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(223140217812409583)
,p_view_id=>wwv_flow_api.id(223138720936409591)
,p_display_seq=>3
,p_column_id=>wwv_flow_api.id(223130061918475511)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(223140787556409580)
,p_view_id=>wwv_flow_api.id(223138720936409591)
,p_display_seq=>4
,p_column_id=>wwv_flow_api.id(223130179849475512)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(223141204343409577)
,p_view_id=>wwv_flow_api.id(223138720936409591)
,p_display_seq=>5
,p_column_id=>wwv_flow_api.id(223130242880475513)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(226805252931737109)
,p_view_id=>wwv_flow_api.id(223138720936409591)
,p_display_seq=>0
,p_column_id=>wwv_flow_api.id(226797349918793206)
,p_is_visible=>false
,p_is_frozen=>true
);
wwv_flow_api.create_ig_report_column(
 p_id=>wwv_flow_api.id(226820664989843522)
,p_view_id=>wwv_flow_api.id(223138720936409591)
,p_display_seq=>6
,p_column_id=>wwv_flow_api.id(226798029363793213)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(39151064927437322)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(14350347073203612)
,p_button_name=>'btnFinalizar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Enviar Solicitud'
,p_button_position=>'BELOW_BOX'
,p_icon_css_classes=>'fa-clipboard-check'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(201887825124006410)
,p_button_sequence=>180
,p_button_plug_id=>wwv_flow_api.id(11648756283192641)
,p_button_name=>'btnAgregarApoderados'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apoderados Acreditados'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-user-plus'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(223132087653475531)
,p_button_sequence=>190
,p_button_plug_id=>wwv_flow_api.id(11648756283192641)
,p_button_name=>'btnGuardarEmpresa'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17195093389493901)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(16241340911241149)
,p_button_name=>'btnLineasAereas'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17195492669493905)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(17195201735493903)
,p_button_name=>'btnMarina'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17195940990493910)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(17195658768493907)
,p_button_name=>'btnRentCar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15767865995671747)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(14351533619203624)
,p_button_name=>'btnHospedaje'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16241284528241148)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(16241016330241146)
,p_button_name=>'btnAgenciaViajes'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16239515566241131)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(14352250579203631)
,p_button_name=>'btnGastronomia'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16239900870241135)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(14354016296203649)
,p_button_name=>'btnAcuatico'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16240907579241145)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(15764073264671709)
,p_button_name=>'btnTematicas'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17199848059493949)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(17199492747493945)
,p_button_name=>'btnTTT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(15764238719671711)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(14349328061203602)
,p_button_name=>'btnGuardarDeclaratoria'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_execute_validations=>'N'
,p_button_condition=>'P7_ID_DECLARATORIA'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(39151260742437324)
,p_branch_name=>'Go To Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P7_MENSAJE_CEDJURIDICA'
,p_branch_condition_text=>'S'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11648996081192643)
,p_name=>'P7_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11649097029192644)
,p_name=>'P7_ID_PROVINCIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Provincia'
,p_source=>'ID_PROVINCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion,id from PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11649152684192645)
,p_name=>'P7_NOMBRE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Nombre Solicitante'
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11649207239192646)
,p_name=>'P7_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>unistr('C\00E9dula de identidad')
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11649319409192647)
,p_name=>'P7_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>unistr('Tel\00E9fono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11649400521192648)
,p_name=>'P7_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Correo para notificaciones'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11649535397192649)
,p_name=>'P7_DIRECCION_EXACTA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>unistr('Direcci\00F3n Exacta')
,p_source=>'DIRECCION_EXACTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>100
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(11649681473192650)
,p_name=>'P7_ID_CANTON'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>unistr('Cant\00F3n')
,p_source=>'ID_CANTON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id from CANTONES@consulta_ictx where prov_id = :P7_ID_PROVINCIA'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P7_ID_PROVINCIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14349249387203601)
,p_name=>'P7_ID_DISTRITO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Distrito'
,p_source=>'ID_DISTRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id from DISTRITOS@consulta_ictx WHERE prov_id = :P7_ID_PROVINCIA AND canton_id = :P7_ID_CANTON'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P7_ID_CANTON,P7_ID_PROVINCIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14349570732203604)
,p_name=>'P7_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_item_source_plug_id=>wwv_flow_api.id(14349328061203602)
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14349631734203605)
,p_name=>'P7_ID_USUARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_item_source_plug_id=>wwv_flow_api.id(14349328061203602)
,p_source=>'ID_USUARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14350067566203609)
,p_name=>'P7_CANTIDAD_COLABORADORES'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_item_source_plug_id=>wwv_flow_api.id(14349328061203602)
,p_prompt=>'Cantidad Colaboradores'
,p_source=>'CANTIDAD_COLABORADORES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'1'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14350190542203610)
,p_name=>'P7_MONTO_INVERSION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_item_source_plug_id=>wwv_flow_api.id(14349328061203602)
,p_prompt=>unistr('Monto Inversi\00F3n')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>'MONTO_INVERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14350202741203611)
,p_name=>'P7_ESTADODT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_item_source_plug_id=>wwv_flow_api.id(14349328061203602)
,p_source=>'ESTADODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14350449556203613)
,p_name=>'P7_TIPO_HOSP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''2'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14350986543203618)
,p_name=>'P7_TIPO_HOSPEDAJE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14351533619203624)
,p_prompt=>unistr('Categor\00EDa del Hospedaje')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion_categoria, id_categoria from catalogo_categoria where estado_categoria = ''AC'' and id_tipoDT = ''2'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14352664624203635)
,p_name=>'P7_RESPALDO_LEGAL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Nota: todos los datos son obligatorios',
unistr('Respaldo legal: publicado en el Decreto Ejecutivo N\00B0 41370- MEIC- TUR del 07 de diciembre del 2018')))
,p_prompt=>'Respaldo Legal'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14352764149203636)
,p_name=>'P7_TIPO_GASTRONOMIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14352250579203631)
,p_prompt=>unistr('Tipo Gastronom\00EDa')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion_categoria, id_categoria from catalogo_categoria where estado_categoria = ''AC'' and id_tipoDT = ''3'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(14354101516203650)
,p_name=>'P7_TRANSPORTE_ACUATICO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(14354016296203649)
,p_prompt=>unistr('Transporte Acu\00E1tico')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion_categoria, id_categoria from catalogo_categoria where estado_categoria = ''AC'' and id_tipoDT = ''6'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15764150865671710)
,p_name=>'P7_ACT_TEMATICAS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(15764073264671709)
,p_prompt=>unistr('Actividades Tem\00E1ticas')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion_categoria, id_categoria from catalogo_categoria where estado_categoria = ''AC'' and id_tipoDT = ''7'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15764452367671713)
,p_name=>'P7_OPERACION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_prompt=>unistr('Operaci\00F3n')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC:En Operaci\00F3n;1,En Proyecto;2')
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15764585366671714)
,p_name=>'P7_PATENTE_MUNICIPAL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_prompt=>'Patente Municipal'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>9000000
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15764606653671715)
,p_name=>'P7_PERMISO_SALUD'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_prompt=>'Permiso Salud'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>9000000
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15765062637671719)
,p_name=>'P7_CRONOGRAMA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_prompt=>unistr('Cronograma de Construcci\00F3n')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>9000000
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15765682420671725)
,p_name=>'P7_NACIONAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Tipo de Identificaci\00F3n')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Nacional;Nacional,Extranjero;Extranjero'
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15765789258671726)
,p_name=>'P7_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>unistr('Raz\00F3n Social')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15765803833671727)
,p_name=>'P7_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Nombre Comercial'
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15767571445671744)
,p_name=>'P7_ZONA_INDIGENA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14351533619203624)
,p_prompt=>unistr('Est\00E1 ubicado en una zona ind\00EDgena?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LISTA_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(15767680605671745)
,p_name=>'P7_AUTORIZACION_ADI'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14351533619203624)
,p_prompt=>unistr('Autorizaci\00F3n de la ADI ')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16083739317727126)
,p_name=>'P7_TIPOS_NAVIERAS'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''17'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16239188415241127)
,p_name=>'P7_RECORDATORIO_OPERACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14352250579203631)
,p_item_default=>unistr('Favor recordar que este tipo de declaratoria solo se puede tramitar si est\00E1 en operaci\00F3n')
,p_prompt=>unistr('Recordatorio de Operaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16239759020241133)
,p_name=>'P7_PERMISO_MOPT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14354016296203649)
,p_prompt=>'Permiso de navegabilidad MOPT'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16239872352241134)
,p_name=>'P7_APROBACION_CIMAT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14354016296203649)
,p_prompt=>unistr('Cuenta con Aprobaci\00F3n CIMAT')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LISTA_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16240009454241136)
,p_name=>'P7_ZONA_INDIGENA_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(15764073264671709)
,p_prompt=>unistr('Est\00E1 ubicado en una zona ind\00EDgena?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LISTA_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16240169635241137)
,p_name=>'P7_AUTORIZACION_ADI_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(15764073264671709)
,p_prompt=>unistr('Autorizaci\00F3n de la ADI ')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(16241187900241147)
,p_name=>'P7_CERTIF_MEIC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(16241016330241146)
,p_prompt=>'Adjuntar Certificado de MEIC'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17195110751493902)
,p_name=>'P7_CERTIF_CEA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(16241340911241149)
,p_prompt=>unistr('Adjuntar certificado de explotaci\00F3n a\00E9reo (CEA)')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17195542277493906)
,p_name=>'P7_CONTRACTO_REGISTRO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(17195201735493903)
,p_prompt=>unistr('Adjuntar Contrato de Concesi\00F3n debidamente inscrito en el Registro P\00FAblico')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17196028422493911)
,p_name=>'P7_FLOTILLA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(17195658768493907)
,p_prompt=>'Digite su flotilla de unidades'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17196173135493912)
,p_name=>'P7_RECORDATORIO_FLOTILLA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(17195658768493907)
,p_item_default=>unistr('Favor recordar que la flotilla m\00EDnima ser\00E1 de 10 unidades y su antig\00FCedad no deber\00E1 ser mayor a cinco (5) a\00F1os')
,p_prompt=>'Recordatorio de Flotilla'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17196244976493913)
,p_name=>'P7_DUENIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(17195658768493907)
,p_prompt=>unistr('Es usted el due\00F1o de los veh\00EDculos?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LISTA_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17196317120493914)
,p_name=>'P7_CONTRATO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(17195658768493907)
,p_prompt=>'Contrato de arrendamiento, leasing o permiso de uso'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17199568490493946)
,p_name=>'P7_RECORDATORIO_OPERACION_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(17199492747493945)
,p_item_default=>unistr('Favor recordar que este tipo de declaratoria solo se puede tramitar si est\00E1 en operaci\00F3n')
,p_prompt=>unistr('Recordatorio de Operaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17199610143493947)
,p_name=>'P7_PERMISO_CTP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(17199492747493945)
,p_prompt=>unistr('Permiso del Consejo de transporte p\00FAblico (CTP)')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17199789428493948)
,p_name=>'P7_CERTIFICADO_TTT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(17199492747493945)
,p_prompt=>unistr('Digitar el n\00FAmero de Certificado TTT')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17396618981280705)
,p_name=>'P7_TIPO_LINEA_A'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''5'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17396746476280706)
,p_name=>'P7_TIPO_ACT_REC_AC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''9'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17396836334280707)
,p_name=>'P7_TIPO_ACT_REC_AE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''11'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17396998073280708)
,p_name=>'P7_TIPO_TRANS_A'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''6'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397086610280709)
,p_name=>'P7_TIPO_ACT_T'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''7'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397199687280710)
,p_name=>'P7_TIPO_RETN_C'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''8'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397256939280711)
,p_name=>'P7_TIPO_AGENCIA_V'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''4'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397387682280712)
,p_name=>'P7_TIPO_GASTRO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''3'''
,p_field_template=>wwv_flow_api.id(24225036011830117)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397442835280713)
,p_name=>'P7_TIPOS_TTT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''12'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397583007280714)
,p_name=>'P7_TIPOS_ORG_CONG'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''13'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397653517280715)
,p_name=>'P7_TIPOS_LOCAL_CONG'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''14'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397792227280716)
,p_name=>'P7_TIPOS_SPA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''15'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17397869567280717)
,p_name=>'P7_TIPOS_MARINA'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(14350347073203612)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'select NOMBRE_TIPODT, ID_TIPODT from tipo_declaratoria where ESTADO_TIPODT = ''AC'' AND ID_TIPODT = ''16'''
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(18032339660966216)
,p_name=>'P7_EXTRANJERO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_use_cache_before_default=>'NO'
,p_prompt=>'DIMEX/Pasaporte/NITE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20003126312367542)
,p_name=>'P7_MONEDA'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_prompt=>'Moneda'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Colones;Colones,D\00F3lares;Dolares')
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39150400980437316)
,p_name=>'P7_MENSAJE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173487909026460609)
,p_name=>'P7_USER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173488296294460612)
,p_name=>'P7_DESCRIPCION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Descripci\00F3n del proyecto')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_cMaxlength=>9000000
,p_begin_on_new_line=>'N'
,p_colspan=>5
,p_grid_column=>7
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'table'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173488361454460613)
,p_name=>'P7_SOLICITUD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(14349328061203602)
,p_prompt=>' Solicitud firmada de la declaratoria'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_cMaxlength=>9000000
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173491056921460640)
,p_name=>'P7_TIPO_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Tipo de Solicitante'
,p_source=>'TIPO_CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC:F\00EDsica;F\00EDsica,Jur\00EDdica;Jur\00EDdica')
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201888284653006414)
,p_name=>'P7_MENSAJE_CEDJURIDICA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(11648756283192641)
,p_item_default=>unistr('* Favor llenar los datos del o los apoderados legales en el bot\00F3n de la parte inferior')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>5
,p_grid_column=>4
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(24225036011830117)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(38477448440951101)
,p_validation_name=>'VALIDAR_CEDULA'
,p_validation_sequence=>10
,p_validation=>'P7_CEDULA'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Formato de c\00E9dula es inv\00E1lido')
,p_validation_condition=>'P7_CEDULA'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(11649207239192646)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(243331789763159644)
,p_validation_name=>'VALIDAR_ID_PROVINCIA_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P7_ID_PROVINCIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar una provincia'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(11649097029192644)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(243331801693159645)
,p_validation_name=>'VALIDAR_ID_CANTON_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P7_ID_CANTON'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un cant\00F3n')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(11649681473192650)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(243331920479159646)
,p_validation_name=>'VALIDAR_ID_DISTRITO_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P7_ID_DISTRITO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un distrito'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(14349249387203601)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(243332084738159647)
,p_validation_name=>'VALIDAR_ID_DIRECCION_EXACTA_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P7_DIRECCION_EXACTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar la direcci\00F3n exacta donde se localiza la empresa')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(11649535397192649)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(243332180497159648)
,p_validation_name=>'VALIDAR_ID_TELEFONO_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P7_TELEFONO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar un n\00FAmero de tel\00E9fono')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(11649319409192647)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(243332324069159650)
,p_validation_name=>'VALIDAR_CANT_COLABORADORES_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P7_CANTIDAD_COLABORADORES'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Debe ingresar un valor v\00E1lido en el campo cantidad de colaboradores')
,p_always_execute=>'Y'
,p_validation_condition=>'P7_CANTIDAD_COLABORADORES'
,p_validation_condition_type=>'ITEM_IS_NULL_OR_ZERO'
,p_when_button_pressed=>wwv_flow_api.id(15764238719671711)
,p_associated_item=>wwv_flow_api.id(14350067566203609)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(247521646166690403)
,p_validation_name=>'VALIDAR_CORREO_FORMAT'
,p_validation_sequence=>10
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P7_CORREO,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'')'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Por favor, ingrese un correo v\00E1lido')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(11649400521192648)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(243332290319159649)
,p_validation_name=>'VALIDAR_CORREO_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P7_CORREO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar un correo electr\00F3nico')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(11649400521192648)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(247521543442690402)
,p_validation_name=>'VALIDAR_MONEDA_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P7_MONEDA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un tipo de moneda'
,p_always_execute=>'Y'
,p_validation_condition=>'P7_MONEDA'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_api.id(15764238719671711)
,p_associated_item=>wwv_flow_api.id(20003126312367542)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(247521466701690401)
,p_validation_name=>'VALIDAR_MONTO_INVERSION_NOT_NULL'
,p_validation_sequence=>30
,p_validation=>'P7_MONTO_INVERSION'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Debe ingresar un valor v\00E1lido en el campo monto de inversi\00F3n')
,p_always_execute=>'Y'
,p_validation_condition=>'P7_MONTO_INVERSION'
,p_validation_condition_type=>'ITEM_IS_NULL_OR_ZERO'
,p_when_button_pressed=>wwv_flow_api.id(15764238719671711)
,p_associated_item=>wwv_flow_api.id(14350190542203610)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15764725186671716)
,p_name=>'DAC_EN_OPERACION'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_OPERACION'
,p_condition_element=>'P7_OPERACION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15764854163671717)
,p_event_id=>wwv_flow_api.id(15764725186671716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_PERMISO_SALUD,P7_PATENTE_MUNICIPAL'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15764904192671718)
,p_event_id=>wwv_flow_api.id(15764725186671716)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_PERMISO_SALUD,P7_PATENTE_MUNICIPAL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15766826283671737)
,p_name=>'DAC_TIPO_FISICA'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_CEDULA'
,p_condition_element=>'P7_TIPO_CEDULA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>unistr('F\00EDsica')
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15766967774671738)
,p_event_id=>wwv_flow_api.id(15766826283671737)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_NACIONAL,P7_NOMBRE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15767041395671739)
,p_event_id=>wwv_flow_api.id(15766826283671737)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_NACIONAL,P7_NOMBRE,P7_CEDULA,P7_EXTRANJERO'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(223132132022475532)
,p_event_id=>wwv_flow_api.id(15766826283671737)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(223132087653475531)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(223132252229475533)
,p_event_id=>wwv_flow_api.id(15766826283671737)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(223132087653475531)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(20001209666367523)
,p_name=>'DAC_NACIONAL'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_NACIONAL'
,p_condition_element=>'P7_NACIONAL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Nacional'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(20001382715367524)
,p_event_id=>wwv_flow_api.id(20001209666367523)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_CEDULA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(20001491509367525)
,p_event_id=>wwv_flow_api.id(20001209666367523)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_CEDULA'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(39150510318437317)
,p_name=>'DAC_MENSAJE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_MENSAJE'
,p_condition_element=>'P7_MENSAJE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39262838319923717)
,p_event_id=>wwv_flow_api.id(39150510318437317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('''Registro ingresado con \00E9xito''')
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(39151172671437323)
,p_event_id=>wwv_flow_api.id(39150510318437317)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15765162465671720)
,p_name=>'DAC_EN_PROYECCION'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_OPERACION'
,p_condition_element=>'P7_OPERACION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15765231953671721)
,p_event_id=>wwv_flow_api.id(15765162465671720)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_CRONOGRAMA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15765356269671722)
,p_event_id=>wwv_flow_api.id(15765162465671720)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_CRONOGRAMA'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15767106926671740)
,p_name=>'DAC_TIPO_JURIDICA'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_CEDULA'
,p_condition_element=>'P7_TIPO_CEDULA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>unistr('Jur\00EDdica')
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15767261129671741)
,p_event_id=>wwv_flow_api.id(15767106926671740)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_RAZON_SOCIAL,P7_MENSAJE_CEDJURIDICA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15767385930671742)
,p_event_id=>wwv_flow_api.id(15767106926671740)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_RAZON_SOCIAL,P7_EXTRANJERO,P7_MENSAJE_CEDJURIDICA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(201890499469006436)
,p_event_id=>wwv_flow_api.id(15767106926671740)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(201887825124006410)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(201890557817006437)
,p_event_id=>wwv_flow_api.id(15767106926671740)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(201887825124006410)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(20001501211367526)
,p_name=>'DAC_EXTRANJERO'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_NACIONAL'
,p_condition_element=>'P7_NACIONAL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Extranjero'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(20001629738367527)
,p_event_id=>wwv_flow_api.id(20001501211367526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_EXTRANJERO'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(20001751209367528)
,p_event_id=>wwv_flow_api.id(20001501211367526)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_EXTRANJERO'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(16083295430727121)
,p_name=>'DAC_HOSPEDAJE'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_HOSP'
,p_condition_element=>'P7_TIPO_HOSP'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17398033489280719)
,p_event_id=>wwv_flow_api.id(16083295430727121)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPO_HOSP'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16083442498727123)
,p_event_id=>wwv_flow_api.id(16083295430727121)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Tipo_Hospedaje'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(14352387902203632)
,p_name=>'DAC_GASTRONOMIA'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPOS2'
,p_condition_element=>'P7_TIPOS2'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P7_TIPOS2'
,p_display_when_cond2=>'3'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16083624775727125)
,p_event_id=>wwv_flow_api.id(14352387902203632)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_TIPOS2'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(14352549948203634)
,p_event_id=>wwv_flow_api.id(14352387902203632)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Tipo_Gastronomia'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17198978082493940)
,p_name=>'DAC_TIPO_GASTRONOMIA'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_GASTRO'
,p_condition_element=>'P7_TIPO_GASTRO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17199096978493941)
,p_event_id=>wwv_flow_api.id(17198978082493940)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPO_GASTRO'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17199155043493942)
,p_event_id=>wwv_flow_api.id(17198978082493940)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Tipo_Gastronomia'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15763273361671701)
,p_name=>'DAC_TRANSPORTE_ACUATICO'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_TRANS_A'
,p_condition_element=>'P7_TIPO_TRANS_A'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'6'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15763314866671702)
,p_event_id=>wwv_flow_api.id(15763273361671701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPO_TRANS_A'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15763421467671703)
,p_event_id=>wwv_flow_api.id(15763273361671701)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Transporte_acuatico'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15763724985671706)
,p_name=>'DAC_ACT_TEMATICAS'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_ACT_T'
,p_condition_element=>'P7_TIPO_ACT_T'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'7'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15763848125671707)
,p_event_id=>wwv_flow_api.id(15763724985671706)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPO_ACT_T'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15763928001671708)
,p_event_id=>wwv_flow_api.id(15763724985671706)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''act_tematicas'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17197196878493922)
,p_name=>'DAC_AGENCIA_VIAJES'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_AGENCIA_V'
,p_condition_element=>'P7_TIPO_AGENCIA_V'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'4'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17197215844493923)
,p_event_id=>wwv_flow_api.id(17197196878493922)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPO_AGENCIA_V'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17197305141493924)
,p_event_id=>wwv_flow_api.id(17197196878493922)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''agencia_viajes'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17197456496493925)
,p_name=>'DAC_LINEAS_AEREAS'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_LINEA_A'
,p_condition_element=>'P7_TIPO_LINEA_A'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'5'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17197522970493926)
,p_event_id=>wwv_flow_api.id(17197456496493925)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPO_LINEA_A'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17197611471493927)
,p_event_id=>wwv_flow_api.id(17197456496493925)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''lineas_aereas'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17197748598493928)
,p_name=>'DAC_MARINA'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPOS_MARINA'
,p_condition_element=>'P7_TIPOS_MARINA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'16'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17197806486493929)
,p_event_id=>wwv_flow_api.id(17197748598493928)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPOS_MARINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17197986437493930)
,p_event_id=>wwv_flow_api.id(17197748598493928)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''marina'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17198055374493931)
,p_name=>'DAC_RENT_CAR'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPO_RETN_C'
,p_condition_element=>'P7_TIPO_RETN_C'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'8'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17198179170493932)
,p_event_id=>wwv_flow_api.id(17198055374493931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPO_RETN_C'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17198259166493933)
,p_event_id=>wwv_flow_api.id(17198055374493931)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''rent_car'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17199931583493950)
,p_name=>'DAC_TRANSPORTE_TERRESTRE'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TIPOS_TTT'
,p_condition_element=>'P7_TIPOS_TTT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'12'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17396268069280701)
,p_event_id=>wwv_flow_api.id(17199931583493950)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P7_TIPOS_TTT'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17396392257280702)
,p_event_id=>wwv_flow_api.id(17199931583493950)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Transporte_terrestre'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(15767988961671748)
,p_name=>'DAC_ZONA_INDIGENA'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_ZONA_INDIGENA'
,p_condition_element=>'P7_ZONA_INDIGENA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'SI'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15768002060671749)
,p_event_id=>wwv_flow_api.id(15767988961671748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_AUTORIZACION_ADI'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(15768103543671750)
,p_event_id=>wwv_flow_api.id(15767988961671748)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_AUTORIZACION_ADI'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17198340176493934)
,p_name=>'DAC_DUENO'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_DUENIO'
,p_condition_element=>'P7_DUENIO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'NO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17198468063493935)
,p_event_id=>wwv_flow_api.id(17198340176493934)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_CONTRATO'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17198596553493936)
,p_event_id=>wwv_flow_api.id(17198340176493934)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_CONTRATO'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17198632958493937)
,p_name=>'DAC_ZONA_INDIGENA_1'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_ZONA_INDIGENA_1'
,p_condition_element=>'P7_ZONA_INDIGENA_1'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'SI'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17198783187493938)
,p_event_id=>wwv_flow_api.id(17198632958493937)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_AUTORIZACION_ADI_1'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17198883054493939)
,p_event_id=>wwv_flow_api.id(17198632958493937)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P7_AUTORIZACION_ADI_1'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(223132507628475536)
,p_name=>'DAC_APODERADO'
,p_event_sequence=>230
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(201887825124006410)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(223131878838475529)
,p_event_id=>wwv_flow_api.id(223132507628475536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355) := null;',
'vRetorno boolean := true;',
'',
'begin',
'',
'-- INSERTAMOS LA EMPRESA',
'        :P7_ID_EMPRESA := PKG_DECLARATORIA.Insertar_Empresa(:P7_ID_PROVINCIA, null, null, :P7_TELEFONO, :P7_CORREO,:P7_DIRECCION_EXACTA, :P7_ID_CANTON,',
'                          :P7_ID_DISTRITO, :P7_TIPO_CEDULA, null, :P7_RAZON_SOCIAL, :P7_NOMBRE_COMERCIAL,  :P7_USER ); --, vMensaje_Retorno, vRetorno);',
'end;'))
,p_attribute_02=>'P7_ID_PROVINCIA,P7_TELEFONO,P7_CORREO,P7_DIRECCION_EXACTA,P7_ID_CANTON,P7_ID_DISTRITO,P7_TIPO_CEDULA,P7_RAZON_SOCIAL,P7_NOMBRE_COMERCIAL,P7_USER,P7_ID_EMPRESA'
,p_attribute_03=>'P7_ID_EMPRESA'
,p_attribute_04=>'N'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(223132691787475537)
,p_event_id=>wwv_flow_api.id(223132507628475536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''DE_ID''); $("#DE_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(226797697742793209)
,p_name=>'New'
,p_event_sequence=>240
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_api.id(223129662349475507)
,p_triggering_element=>'TIPO_IDENTIFCACION'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(226797718850793210)
,p_event_id=>wwv_flow_api.id(226797697742793209)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :ID_EMPRESA := :P7_ID_EMPRESA;',
'end;'))
,p_attribute_02=>'P7_ID_EMPRESA,ID_EMPRESA'
,p_attribute_03=>'ID_EMPRESA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(226798162774793214)
,p_name=>'New_1'
,p_event_sequence=>250
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(223129662349475507)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(226798249697793215)
,p_event_id=>wwv_flow_api.id(226798162774793214)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(226798383639793216)
,p_name=>'DAC_ID_EMPRESA'
,p_event_sequence=>260
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_ID_EMPRESA'
,p_condition_element=>'P7_ID_EMPRESA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(226798401444793217)
,p_event_id=>wwv_flow_api.id(226798383639793216)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(14349328061203602)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(226798505968793218)
,p_event_id=>wwv_flow_api.id(226798383639793216)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(14349328061203602)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(201889922419006431)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_EMPRESA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355) := null;',
'vRetorno boolean := true;',
'',
'begin',
'  --  raise_application_error(-20000, ''Error'');',
'',
'-- INSERTAMOS LA EMPRESA',
'    if :P7_CEDULA is not null   then',
'        :P7_ID_EMPRESA := PKG_DECLARATORIA.Insertar_Empresa(:P7_ID_PROVINCIA, :P7_NOMBRE, :P7_CEDULA, :P7_TELEFONO, :P7_CORREO,:P7_DIRECCION_EXACTA, :P7_ID_CANTON, :P7_ID_DISTRITO, :P7_TIPO_CEDULA,:P7_NACIONAL,',
'                                                            :P7_RAZON_SOCIAL, :P7_NOMBRE_COMERCIAL,  :P7_USER);-- , vMensaje_Retorno, vRetorno);',
'      else',
'        :P7_ID_EMPRESA := PKG_DECLARATORIA.Insertar_Empresa(:P7_ID_PROVINCIA, :P7_NOMBRE, :P7_EXTRANJERO, :P7_TELEFONO, :P7_CORREO,',
'                                          :P7_DIRECCION_EXACTA, :P7_ID_CANTON, :P7_ID_DISTRITO, :P7_TIPO_CEDULA, :P7_NACIONAL,',
'                                          :P7_RAZON_SOCIAL, :P7_NOMBRE_COMERCIAL,  :P7_USER );--, vMensaje_Retorno, vRetorno);',
'    end if; ',
'end;'))
,p_process_error_message=>'Error al guardar los datos de empresa, si el error persiste contacte al administrador del sistema.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(223132087653475531)
,p_process_success_message=>unistr('Los datos de empresa fueron guardados con \00E9xito. Por favor, continue con el registro de la declaratoria.')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(15764396000671712)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_DT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355) := null;',
'vRetorno boolean := true;',
'',
'vsolicitud BLOB;',
'vTipoArchivo_S VARCHAR2(255);',
'vNombreArchivo_S VARCHAR2(255);',
'vDescripcion BLOB;',
'vTipoArchivo_D VARCHAR2(255);',
'vNombreArchivo_D VARCHAR2(255);',
'',
'vPermiso_salud BLOB;',
'vTipoArchivo_PS VARCHAR2(255);',
'vNombreArchivo_PS VARCHAR2(255);',
'vPatente_municipal BLOB;',
'vTipoArchivo_PM VARCHAR2(255);',
'vNombreArchivo_PM VARCHAR2(255);',
'vCronograma BLOB;',
'vTipoArchivo_C VARCHAR2(255);',
'vNombreArchivo_C VARCHAR2(255);',
'prueba VARCHAR2(300);',
'',
'begin',
'    ',
' /*   -- INSERTAMOS LA EMPRESA',
'    if :P7_TIPO_CEDULA = ''Fisica'' then',
'        if :P7_CEDULA is not null   then',
'            :P7_ID_EMPRESA := PKG_DECLARATORIA.Insertar_Empresa(:P7_ID_PROVINCIA, :P7_NOMBRE, :P7_CEDULA, :P7_TELEFONO, :P7_CORREO,:P7_DIRECCION_EXACTA, :P7_ID_CANTON, :P7_ID_DISTRITO, :P7_TIPO_CEDULA,:P7_NACIONAL,',
'                                                                :P7_RAZON_SOCIAL, :P7_NOMBRE_COMERCIAL,  :P7_USER , vMensaje_Retorno, vRetorno);',
'          else',
'            :P7_ID_EMPRESA := PKG_DECLARATORIA.Insertar_Empresa(:P7_ID_PROVINCIA, :P7_NOMBRE, :P7_EXTRANJERO, :P7_TELEFONO, :P7_CORREO,',
'                                              :P7_DIRECCION_EXACTA, :P7_ID_CANTON, :P7_ID_DISTRITO, :P7_TIPO_CEDULA, :P7_NACIONAL,',
'                                              :P7_RAZON_SOCIAL, :P7_NOMBRE_COMERCIAL,  :P7_USER , vMensaje_Retorno, vRetorno);',
'        end if; ',
'    end if; ',
'   */',
'    -- VALIDAMOS LA EMPRESA E INSERTAMOS LA DECLARATORIA',
'	if :P7_ID_EMPRESA is not null   then',
'        if :P7_SOLICITUD is not null    then',
'            if :P7_DESCRIPCION is not null then',
'                SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vsolicitud,vTipoArchivo_S,vNombreArchivo_S FROM APEX_APPLICATION_TEMP_FILES',
'                             WHERE NAME = :P7_SOLICITUD;',
'							 ',
'                SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vDescripcion,vTipoArchivo_D,vNombreArchivo_D FROM APEX_APPLICATION_TEMP_FILES',
'                             WHERE NAME = :P7_DESCRIPCION;',
'',
'                :P7_ID_DECLARATORIA := PKG_DECLARATORIA.Insertar_Declaratoria( :P7_USER, :P7_ID_EMPRESA, :P7_CANTIDAD_COLABORADORES, :P7_MONEDA, :P7_MONTO_INVERSION, ',
'                                                      vsolicitud, vTipoArchivo_S, vNombreArchivo_S, vDescripcion, vTipoArchivo_D, vNombreArchivo_D, vMensaje_Retorno, vRetorno);',
'            end if;',
'		end if;',
'        ',
'        ',
'		-- VALIDAMOS  LA DECLARATORIA E INSERTAMOS EL TIPO DE DT',
'		if :P7_ID_DECLARATORIA is not null   then',
'			if :P7_PERMISO_SALUD is not null then --and :P7_PATENTE_MUNICIPAL is not NULL',
'				if :P7_PATENTE_MUNICIPAL is not null then',
'					SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vPermiso_salud,vTipoArchivo_PS,vNombreArchivo_PS FROM APEX_APPLICATION_TEMP_FILES',
'						 WHERE NAME = :P7_PERMISO_SALUD;',
'			',
'					SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vPatente_municipal,vTipoArchivo_PM,vNombreArchivo_PM FROM APEX_APPLICATION_TEMP_FILES',
'						 WHERE NAME = :P7_PATENTE_MUNICIPAL;',
'',
'					PKG_DECLARATORIA.Insertar_Operacion(:P7_OPERACION, vPermiso_salud, NULL, vPatente_municipal, :P7_ID_DECLARATORIA,',
'						 vTipoArchivo_PS, NULL, vTipoArchivo_PM,vNombreArchivo_PS,NULL,vNombreArchivo_PM, vMensaje_Retorno, vRetorno);',
'				end if;',
'			end if;',
'',
'			if :P7_CRONOGRAMA is not null then',
'					SELECT BLOB_CONTENT, MIME_TYPE,FILENAME INTO vCronograma,vTipoArchivo_C,vNombreArchivo_C FROM APEX_APPLICATION_TEMP_FILES',
'						 WHERE NAME = :P7_CRONOGRAMA;',
'					',
'					PKG_DECLARATORIA.Insertar_Operacion(:P7_OPERACION, NULL, vCronograma, NULL, :P7_ID_DECLARATORIA,',
'						 NULL, vTipoArchivo_C, NULL, NULL, vNombreArchivo_C, NULL, vMensaje_Retorno, vRetorno);',
'			end if;',
'		end if;',
'     end if;',
'end;'))
,p_process_error_message=>'Error al guardar los datos de la declaratoria, si el error persiste contacte al administrador del sistema.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15764238719671711)
,p_process_success_message=>unistr('Datos de la declataroria fueron guardados con \00E9xito. Por favor, continue seleccionando los tipos de declatoria.')
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18030860191966201)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_HOSP'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'    ',
'     if :P7_AUTORIZACION_ADI is not NULL',
'         then',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P7_AUTORIZACION_ADI;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 2, vArchivo, NULL, NULL, ',
'                        vNombreArchivo, NULL, :P7_ZONA_INDIGENA, :P7_TIPO_HOSPEDAJE, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'          end if;',
'     ',
'     if :P7_AUTORIZACION_ADI is NULL',
'         then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 2, NULL, NULL, NULL, ',
'                       NULL, NULL, :P7_ZONA_INDIGENA, :P7_TIPO_HOSPEDAJE, NULL, vMensaje_Retorno, vRetorno);',
'         end if;',
'          if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(15767865995671747)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18031853831966211)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_RENT_CAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'    ',
'     if :P7_CONTRATO is not NULL',
'         then',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P7_CONTRATO;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 8, vArchivo, NULL, :P7_FLOTILLA, ',
'                        vNombreArchivo, NULL, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'          end if;',
'     ',
'     if :P7_CONTRATO is NULL',
'         then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 8, NULL, NULL, :P7_FLOTILLA,',
'                        NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'         end if;',
'              if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17195940990493910)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18031646416966209)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_ACT_TEMA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'    ',
'     if :P7_AUTORIZACION_ADI_1 is not NULL',
'         then',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P7_AUTORIZACION_ADI_1;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 7, vArchivo, NULL, NULL,',
'                        vNombreArchivo, NULL, :P7_ZONA_INDIGENA_1, :P7_ACT_TEMATICAS, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'          end if;',
'     ',
'     if :P7_AUTORIZACION_ADI_1 is NULL',
'         then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 7, NULL, NULL, NULL,',
'                       NULL, NULL, :P7_ZONA_INDIGENA_1, :P7_ACT_TEMATICAS, NULL, vMensaje_Retorno, vRetorno);',
'         end if;',
'              if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16240907579241145)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18030949845966202)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_GASTRO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'',
'begin',
'      PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 3, NULL, NULL, NULL, NULL, NULL, NULL,',
'                                                  :P7_TIPO_GASTRONOMIA, NULL, vMensaje_Retorno, vRetorno);',
'         if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'     ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16239515566241131)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18031042300966203)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_AGENCIA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P7_CERTIF_MEIC;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 4, vArchivo, NULL, NULL,',
'                        vNombreArchivo, NULL, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'                        ',
'         if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16241284528241148)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18031913875966212)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_TTT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P7_PERMISO_CTP;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 12, vArchivo, NULL, NULL, ',
'                        vNombreArchivo, :P7_CERTIFICADO_TTT, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'          if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17199848059493949)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18031128933966204)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_LINEAS_AEREAS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P7_CERTIF_CEA;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 5, vArchivo, NULL, NULL,',
'                        vNombreArchivo, NULL, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'          if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17195093389493901)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18032090458966213)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_MARINA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P7_CONTRACTO_REGISTRO;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 16, vArchivo, NULL, NULL,',
'                        vNombreArchivo, NULL, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'                        ',
'             if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(17195492669493905)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(18031361542966206)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_TRANS_ACUATICOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P7_PERMISO_MOPT;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 6, vArchivo, :P7_APROBACION_CIMAT, NULL,',
'                        vNombreArchivo, NULL, NULL, :P7_TRANSPORTE_ACUATICO, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'                        ',
'           if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(16239900870241135)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(226797566501793208)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(223129662349475507)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'PRC_INSERTAR_APODERADOS_LEGALES'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11648838646192642)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(11648756283192641)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'PRC_INICIO_REGISTRO_DR'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(14349475726203603)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(14349328061203602)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'PRC_INICIO_REGISTRO_DT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39151351829437325)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P7_MENSAJE := null;',
':P7_USER := :APP_USER;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P7_ID_DECLARATORIA'
,p_process_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39639796341928502)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_FINALIZAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'',
'begin',
'',
'    if :P7_TIPO_ACT_REC_AC is not NULL',
'    then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 9, NULL, NULL, NULL,',
'                       NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'    end if;',
'    ',
'    if :P7_TIPO_ACT_REC_AE is not NULL',
'    then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 11, NULL, NULL, NULL,',
'                       NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'    end if;',
'    if :P7_TIPOS_ORG_CONG is not NULL',
'    then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 13, NULL, NULL, NULL,',
'                       NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'    end if;',
'    if :P7_TIPOS_LOCAL_CONG is not NULL',
'    then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 14, NULL, NULL, NULL,',
'                       NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'    end if;',
'    if :P7_TIPOS_SPA is not NULL',
'    then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 15, NULL, NULL, NULL,',
'                       NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'    end if;',
'    ',
'    if :P7_TIPOS_NAVIERAS is not NULL',
'    then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P7_ID_DECLARATORIA, 17, NULL, NULL, NULL,',
'                       NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'    end if;',
'    ',
'    PKG_UTILIDADES.Notifica_Solicitud(1);',
'    ',
'    if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P7_MENSAJE := ''S'';',
'             else',
'             :P7_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_process_error_message=>'Error al generar la solicitud, si el error persiste contacte al administrador del sistema.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(39151064927437322)
,p_process_success_message=>unistr('La solicitud de declaratoria tur\00EDstica fue ingresada con \00E9xito')
);
wwv_flow_api.component_end;
end;
/
