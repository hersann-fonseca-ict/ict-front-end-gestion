prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>100
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>'100-Inicio'
,p_alias=>'100-INICIO'
,p_step_title=>'100-Inicio'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(24252047625830096)
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ADRIANA.RUBIO'
,p_last_upd_yyyymmddhh24miss=>'20210702151411'
);
wwv_flow_api.component_end;
end;
/
