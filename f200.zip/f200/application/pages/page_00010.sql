prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>unistr('Modal: Respuesta Declaraci\00F3n T\00FAristica')
,p_alias=>'MODAL-RESPUESTA-EMPRESA-DT'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Respuesta Declaraci\00F3n T\00FAristica')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>wwv_flow_api.id(24114060378830160)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241011095923'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(173167087634417650)
,p_plug_name=>unistr('Datos de la notificaci\00F3n de respuesta')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24136760250830149)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT empresa.id_empresa , empresa.nombre_solicitante, empresa.razon_social, empresa.nombre_comercial, empresa.correo, empresa.telefono,',
'declaratoria_turistica.id_declaratoria , declaratoria_turistica.fecha_registro, ',
'declaratoria_turistica.id_analista, declaratoria_turistica.estadodt',
'FROM empresa',
'   JOIN declaratoria_turistica ON empresa.id_empresa = declaratoria_turistica.id_empresa ',
'   WHERE empresa.cedula_solicitante = :APP_USER',
'  '))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(173170826202417663)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24137721610830149)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(173171296288417664)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(173170826202417663)
,p_button_name=>'BTN_CERRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(173173219873417667)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(173170826202417663)
,p_button_name=>'BTN_ENVIAR_MSJ'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Mensaje'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173167473894417656)
,p_name=>'P10_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173167776396417658)
,p_name=>'P10_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173168191544417659)
,p_name=>'P10_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173168567213417660)
,p_name=>'P10_FECHA_REGISTRO'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'FECHA_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173168985020417661)
,p_name=>'P10_ESTADODT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'ESTADODT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173487185619460601)
,p_name=>'P10_NOTA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_prompt=>'Seleccione el archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173487334480460603)
,p_name=>'P10_CUERPO_CORREO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Ingrese el texto del mensaje:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(173487501147460605)
,p_name=>'P10_ID_ANALISTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'ID_ANALISTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201888578341006417)
,p_name=>'P10_NOMBRE_SOLICITANTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'NOMBRE_SOLICITANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201888638073006418)
,p_name=>'P10_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201888739245006419)
,p_name=>'P10_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(201888881750006420)
,p_name=>'P10_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(173167087634417650)
,p_item_source_plug_id=>wwv_flow_api.id(173167087634417650)
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(249899310391571948)
,p_validation_name=>'VALIDAR_NOTA_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P10_NOTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe adjuntar un archivo'
,p_always_execute=>'Y'
,p_validation_condition=>'NULL'
,p_validation_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_when_button_pressed=>wwv_flow_api.id(173173219873417667)
,p_associated_item=>wwv_flow_api.id(173487185619460601)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(173171369220417664)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(173171296288417664)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(173172172296417665)
,p_event_id=>wwv_flow_api.id(173171369220417664)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(257022288363132139)
,p_name=>'DAC_ESTADODT_IS_1_6_7_9'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_ESTADODT'
,p_condition_element=>'P10_ESTADODT'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'1,6,7,9'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(257022385196132140)
,p_event_id=>wwv_flow_api.id(257022288363132139)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(173173219873417667)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(257022528010132142)
,p_event_id=>wwv_flow_api.id(257022288363132139)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_NOTA,P10_CUERPO_CORREO'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(173487648376460606)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ENVIAR_MSJ'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vEstado NUMBER:= 8;',
'vCorreo VARCHAR2(60);',
'vCuerpoCorreo VARCHAR2(3500);',
'vid_secuencia NUMBER;',
'vUser VARCHAR2(255);',
'',
'',
'begin',
'	',
'    vUser := PKG_USUARIOS.Consulta_usuario(:APP_USER);',
'    ',
'	SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P10_NOTA;',
'	vid_secuencia := SEQ_ID_ANOTACIONES.nextval;',
'    ',
'	PKG_DECLARATORIA.Insertar_Anotacion(TO_CHAR(vid_secuencia), vArchivo, vTipoArchivo, vNombreArchivo, vUser, :P10_ID_DECLARATORIA, null, vMensaje_Retorno, vRetorno);',
'                                        ',
'    vCorreo := PKG_USUARIOS.Consulta_correo(:P10_ID_ANALISTA);',
'	',
unistr('	vCuerpoCorreo := ''La empresa '' || :P10_NOMBRE_COMERCIAL || '' la cual tiene el expediente de Declaratoria Tur\00EDstica '' || :P10_ID_DECLARATORIA || '' ha respondido la notificaci\00F3n. Y ha respondido: "'' || :P10_CUERPO_CORREO || ''"'';'),
'	',
'	PKG_CORREOS.envio_correo_adjun(vCorreo, ''Respuesta de la empresa'' , vCuerpoCorreo , TO_CHAR(vid_secuencia));',
'',
'	PKG_DECLARATORIA.Actualizar_Estado(:P10_ID_DECLARATORIA, vEstado);',
'    ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(173173219873417667)
,p_process_success_message=>unistr('Respuesta enviada con \00E9xito')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(173174854833417668)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'BTN_ENVIAR_MSJ'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(173174094140417667)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(173167087634417650)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form RespuestaDT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
