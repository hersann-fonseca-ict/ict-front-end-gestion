prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>'Form: Home'
,p_alias=>'FORM-HOME'
,p_step_title=>unistr('Sistema Gesti\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-mainContent{',
'    background-image: url(''#APP_IMAGES#SistemaVentaUnico.png'');',
'    background-position : center;',
'    background-repeat : no-repeat;',
unistr('\00A0\00A0  background-size : contain;\00A0'),
unistr('\00A0\00A0 '),
'    width: auto;',
unistr('\00A0\00A0\00A0 height: 0px;\00A0'),
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240919124659'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24259756193830091)
,p_plug_name=>unistr('Sistema de Gesti\00F3n')
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_api.id(24154527762830141)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NEVER'
,p_region_image=>'#APP_IMAGES#indice.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
