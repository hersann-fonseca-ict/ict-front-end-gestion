prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>14
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>unistr('Form: Tipos de Declaratoria Tur\00EDstica')
,p_alias=>'FORM-TIPOS-DT'
,p_step_title=>unistr('Tipos de Declaratoria Tur\00EDstica')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function validateNumber(event) {',
'  var keyCode = event.keyCode;',
unistr('  var excludedKeys = [8, 37, 39, 46];//Teclas extra que queremos que el campo acepte aparte de los n\00FAmeros, como el backspace'),
unistr('//Realizamos la validaci\00F3n de la tecla ingresada'),
'  if (!((keyCode >= 48 && keyCode <= 57) ||',
'      (keyCode >= 96 && keyCode <= 105) ||',
'      (excludedKeys.includes(keyCode)))) {',
'    event.preventDefault();',
'',
'  }',
'}  '))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241017135339'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(247999105178937624)
,p_plug_name=>'Tipos de Declaratoria'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(24174565993830135)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Registro de datos para la solicitud de Declaratoria Tur\00EDstica</h3></center>')))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(262770670795357412)
,p_plug_name=>'Tipos de Declaratoria'
,p_parent_plug_id=>wwv_flow_api.id(247999105178937624)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24136760250830149)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(262771857341357424)
,p_plug_name=>'Tipo: Hospedaje'
,p_region_name=>'Tipo_Hospedaje'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(262772574301357431)
,p_plug_name=>unistr('Tipo: Gastronom\00EDa')
,p_region_name=>'Tipo_Gastronomia'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(262774340018357449)
,p_plug_name=>unistr('Tipo: Transporte Acu\00E1tico')
,p_region_name=>'Transporte_acuatico'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(264184396986825509)
,p_plug_name=>unistr('Tipo: Actividades Tem\00E1ticas')
,p_region_name=>'act_tematicas'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(264661340052394946)
,p_plug_name=>'Tipo: Agencia Viajes'
,p_region_name=>'agencia_viajes'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(264661664633394949)
,p_plug_name=>unistr('Tipo: Lineas \00C1ereas')
,p_region_name=>'lineas_aereas'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(265615525457647703)
,p_plug_name=>'Tipo: Marina'
,p_region_name=>'marina'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(265615982490647707)
,p_plug_name=>'Tipo: Rent a Car'
,p_region_name=>'rent_car'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>90
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(265619816469647745)
,p_plug_name=>'Tipo: Transporte Terrestre'
,p_region_name=>'Transporte_terrestre'
,p_parent_plug_id=>wwv_flow_api.id(262770670795357412)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>100
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248000929764937625)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(247999105178937624)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248435663029153813)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(264661664633394949)
,p_button_name=>'BTN_INSERTAR_LINEAS_AEREAS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248436722601153814)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(265615525457647703)
,p_button_name=>'BTN_INSERTAR_MARINA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248437865656153815)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(265615982490647707)
,p_button_name=>'BTN_INSERTAR_RENT_A_CAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248427358918153805)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(262771857341357424)
,p_button_name=>'BTN_INSERTAR_HOSPEDAJE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248434511253153812)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(264661340052394946)
,p_button_name=>'BTN_INSERTAR_AGENCIA_VIAJES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248429257844153807)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(262772574301357431)
,p_button_name=>'BTN_INSERTAR_GASTRONOMIA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248430792659153808)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(262774340018357449)
,p_button_name=>'BTN_INSERTAR_TRANS_ACUATICO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248432643317153811)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(264184396986825509)
,p_button_name=>'BTN_INSERTAR_ACT_TEMATICAS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248440143947153817)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(265619816469647745)
,p_button_name=>'BTN_INSERTAR_TRANS_TERRESTRE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248001045497937625)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(247999105178937624)
,p_button_name=>'ENVIAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_button_condition=>'P14_ID_DECLARATORIA'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(248002669133937626)
,p_branch_name=>'Go To Page 9'
,p_branch_action=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(248001045497937625)
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248427754917153806)
,p_name=>'P14_TIPO_HOSPEDAJE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(262771857341357424)
,p_prompt=>unistr('Categor\00EDa del Hospedaje')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion_categoria, id_categoria from catalogo_categoria where estado_categoria = ''AC'' and id_tipoDT = ''2'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248428133174153806)
,p_name=>'P14_ZONA_INDIGENA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(262771857341357424)
,p_prompt=>unistr('Est\00E1 ubicado en una zona ind\00EDgena?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LISTA_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248428588475153806)
,p_name=>'P14_AUTORIZACION_ADI'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(262771857341357424)
,p_prompt=>unistr('Autorizaci\00F3n de la ADI ')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248429642629153807)
,p_name=>'P14_TIPO_GASTRONOMIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(262772574301357431)
,p_prompt=>unistr('Tipo Gastronom\00EDa')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion_categoria, id_categoria from catalogo_categoria where estado_categoria = ''AC'' and id_tipoDT = ''3'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248430044300153808)
,p_name=>'P14_RECORDATORIO_OPERACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(262772574301357431)
,p_item_default=>unistr('Favor recordar que este tipo de declaratoria solo se puede tramitar si est\00E1 en operaci\00F3n')
,p_prompt=>unistr('Recordatorio de Operaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248431126525153808)
,p_name=>'P14_TRANSPORTE_ACUATICO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(262774340018357449)
,p_prompt=>unistr('Transporte Acu\00E1tico')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion_categoria, id_categoria from catalogo_categoria where estado_categoria = ''AC'' and id_tipoDT = ''6'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248431526933153809)
,p_name=>'P14_APROBACION_CIMAT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(262774340018357449)
,p_prompt=>unistr('Cuenta con Aprobaci\00F3n CIMAT')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LISTA_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248431931237153810)
,p_name=>'P14_PERMISO_MOPT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(262774340018357449)
,p_prompt=>'Permiso de navegabilidad MOPT'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248433038952153811)
,p_name=>'P14_ACT_TEMATICAS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(264184396986825509)
,p_prompt=>unistr('Actividades Tem\00E1ticas')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion_categoria, id_categoria from catalogo_categoria where estado_categoria = ''AC'' and id_tipoDT = ''7'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248433480708153811)
,p_name=>'P14_ZONA_INDIGENA_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(264184396986825509)
,p_prompt=>unistr('Est\00E1 ubicado en una zona ind\00EDgena?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LISTA_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248433895644153812)
,p_name=>'P14_AUTORIZACION_ADI_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(264184396986825509)
,p_prompt=>unistr('Autorizaci\00F3n de la ADI ')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248434926830153812)
,p_name=>'P14_CERTIF_MEIC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(264661340052394946)
,p_prompt=>'Adjuntar Certificado de MEIC'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248436000340153813)
,p_name=>'P14_CERTIF_CEA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(264661664633394949)
,p_prompt=>unistr('Adjuntar certificado de explotaci\00F3n a\00E9reo (CEA)')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248437189700153814)
,p_name=>'P14_CONTRACTO_REGISTRO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(265615525457647703)
,p_prompt=>unistr('Adjuntar Contrato de Concesi\00F3n debidamente inscrito en el Registro P\00FAblico')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248438250196153815)
,p_name=>'P14_FLOTILLA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(265615982490647707)
,p_prompt=>'Cantidad de unidades de la flotilla'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'10'
,p_attribute_03=>'left'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248438632503153816)
,p_name=>'P14_RECORDATORIO_FLOTILLA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(265615982490647707)
,p_item_default=>unistr('Favor recordar que la flotilla m\00EDnima ser\00E1 de 10 unidades y su antig\00FCedad no deber\00E1 ser mayor a cinco (5) a\00F1os')
,p_prompt=>'Recordatorio de Flotilla'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248439071618153816)
,p_name=>'P14_DUENIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(265615982490647707)
,p_prompt=>unistr('Es usted el due\00F1o de los veh\00EDculos?')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LISTA_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(16087362638114495)||'.'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248439453361153816)
,p_name=>'P14_CONTRATO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(265615982490647707)
,p_prompt=>'Contrato de arrendamiento, leasing o permiso de uso'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248440548499153817)
,p_name=>'P14_CERTIFICADO_TTT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(265619816469647745)
,p_prompt=>unistr('Digitar el n\00FAmero de Certificado TTT')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248440996760153818)
,p_name=>'P14_RECORDATORIO_OPERACION_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(265619816469647745)
,p_item_default=>unistr('Favor recordar que este tipo de declaratoria solo se puede tramitar si est\00E1 en operaci\00F3n')
,p_prompt=>unistr('Recordatorio de Operaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248441316927153818)
,p_name=>'P14_PERMISO_CTP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(265619816469647745)
,p_prompt=>unistr('Permiso del Consejo de transporte p\00FAblico (CTP)')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>500
,p_cMaxlength=>500
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248523335738676802)
,p_name=>'P14_MENSAJE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(262770670795357412)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248528164586788858)
,p_name=>'P14_ID_DECLARATORIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(262770670795357412)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(256561998659921403)
,p_name=>'P14_RB_TIPOS_DECLARATORIAS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(262770670795357412)
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NOMBRE_TIPODT, ID_TIPODT ',
'FROM tipo_declaratoria ',
'WHERE ESTADO_TIPODT = ''AC'' AND TIPO_OPERACION = :P14_TIPO_OPERACION OR TIPO_OPERACION = 3',
'ORDER BY NOMBRE_TIPODT ASC;'))
,p_grid_column=>2
,p_display_when=>'P14_ID_DECLARATORIA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(258245111321473205)
,p_name=>'P14_TIPO_OPERACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(262770670795357412)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(256562232666921406)
,p_validation_name=>'VALIDAR_ID_TIPO_DECLARATORIA_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P14_MENSAJE'
,p_validation2=>'S'
,p_validation_type=>'ITEM_IN_VALIDATION_EQ_STRING2'
,p_error_message=>'Debe seleccionar un tipo de declaratoria'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(248001045497937625)
,p_associated_item=>wwv_flow_api.id(256561998659921403)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257018411118132101)
,p_validation_name=>'VALIDAR_TIPO_HOSPEDAJE_NOT_NULL'
,p_validation_sequence=>20
,p_validation=>'P14_TIPO_HOSPEDAJE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un tipo de hospedaje'
,p_when_button_pressed=>wwv_flow_api.id(248427358918153805)
,p_associated_item=>wwv_flow_api.id(248427754917153806)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257018670401132103)
,p_validation_name=>'VALIDAR_HOSPEDAJE_ZONA_INDIGENA_NOT_NULL'
,p_validation_sequence=>30
,p_validation=>'P14_ZONA_INDIGENA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(248427358918153805)
,p_associated_item=>wwv_flow_api.id(248428133174153806)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257018714770132104)
,p_validation_name=>'VALIDAR_AUTORIZACION_ADI_NOT_NULL'
,p_validation_sequence=>40
,p_validation=>'P14_AUTORIZACION_ADI'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un archivo'
,p_when_button_pressed=>wwv_flow_api.id(248427358918153805)
,p_associated_item=>wwv_flow_api.id(248428588475153806)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257018580803132102)
,p_validation_name=>'VALIDAR_TIPO_GASTRONOMIA_NOT_NULL'
,p_validation_sequence=>50
,p_validation=>'P14_TIPO_GASTRONOMIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un tipo de gastronom\00EDa')
,p_when_button_pressed=>wwv_flow_api.id(248429257844153807)
,p_associated_item=>wwv_flow_api.id(248429642629153807)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257018866671132105)
,p_validation_name=>'VALIDAR_TRANSPORTE_ACUATICO_NOT_NULL'
,p_validation_sequence=>60
,p_validation=>'P14_TRANSPORTE_ACUATICO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un tipo de transporte acu\00E1tico')
,p_when_button_pressed=>wwv_flow_api.id(248430792659153808)
,p_associated_item=>wwv_flow_api.id(248431126525153808)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257018904049132106)
,p_validation_name=>'VALIDAR_APROBACION_CIMAT_NOT_NULL'
,p_validation_sequence=>70
,p_validation=>'P14_APROBACION_CIMAT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(248430792659153808)
,p_associated_item=>wwv_flow_api.id(248431526933153809)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019049701132107)
,p_validation_name=>'VALIDAR_PERMISO_MOPT_NOT_NULL'
,p_validation_sequence=>80
,p_validation=>'P14_PERMISO_MOPT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un archivo'
,p_when_button_pressed=>wwv_flow_api.id(248430792659153808)
,p_associated_item=>wwv_flow_api.id(248431931237153810)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019132351132108)
,p_validation_name=>'VALIDAR_ACT_TEMATICAS_NOT_NULL'
,p_validation_sequence=>90
,p_validation=>'P14_ACT_TEMATICAS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una actividad tem\00E1tica')
,p_when_button_pressed=>wwv_flow_api.id(248432643317153811)
,p_associated_item=>wwv_flow_api.id(248433038952153811)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019270509132109)
,p_validation_name=>'VALIDAR_ACT_TEMATICAS_ZONA_INDIGINA_NOT_NULL'
,p_validation_sequence=>100
,p_validation=>'P14_ZONA_INDIGENA_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(248432643317153811)
,p_associated_item=>wwv_flow_api.id(248433480708153811)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019328239132110)
,p_validation_name=>'VALIDAR_ACT_TEMATICAS_AUTORIZACION_ADI_NOT_NULL'
,p_validation_sequence=>110
,p_validation=>'P14_AUTORIZACION_ADI_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un archivo'
,p_when_button_pressed=>wwv_flow_api.id(248432643317153811)
,p_associated_item=>wwv_flow_api.id(248433895644153812)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019490389132111)
,p_validation_name=>'VALIDAR_CERTIF_MEIC_NOT_NULL'
,p_validation_sequence=>120
,p_validation=>'P14_CERTIF_MEIC'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un archivo'
,p_when_button_pressed=>wwv_flow_api.id(248434511253153812)
,p_associated_item=>wwv_flow_api.id(248434926830153812)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019514791132112)
,p_validation_name=>'VALIDAR_CERTIF_CEA_NOT_NULL'
,p_validation_sequence=>130
,p_validation=>'P14_CERTIF_CEA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un archivo'
,p_when_button_pressed=>wwv_flow_api.id(248435663029153813)
,p_associated_item=>wwv_flow_api.id(248436000340153813)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019641030132113)
,p_validation_name=>'VALIDAR_CONTRACTO_REGISTRO_NOT_NULL'
,p_validation_sequence=>140
,p_validation=>'P14_CONTRACTO_REGISTRO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un archivo'
,p_when_button_pressed=>wwv_flow_api.id(248436722601153814)
,p_associated_item=>wwv_flow_api.id(248437189700153814)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019799303132114)
,p_validation_name=>'VALIDAR_FLOTILLA_NOT_NULL'
,p_validation_sequence=>150
,p_validation=>'P14_FLOTILLA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar la cantidad de unidades de la flotilla'
,p_when_button_pressed=>wwv_flow_api.id(248437865656153815)
,p_associated_item=>wwv_flow_api.id(248438250196153815)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019841744132115)
,p_validation_name=>'VALIDAR_DUENIO_NOT_NULL'
,p_validation_sequence=>160
,p_validation=>'P14_DUENIO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(248437865656153815)
,p_associated_item=>wwv_flow_api.id(248439071618153816)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257019988249132116)
,p_validation_name=>'VALIDAR_CONTRATO_NOT_NULL'
,p_validation_sequence=>170
,p_validation=>'P14_CONTRATO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un archivo'
,p_when_button_pressed=>wwv_flow_api.id(248437865656153815)
,p_associated_item=>wwv_flow_api.id(248439453361153816)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257020000787132117)
,p_validation_name=>'VALIDAR_CERTIFICADO_TTT_NOT_NULL'
,p_validation_sequence=>180
,p_validation=>'P14_CERTIFICADO_TTT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el n\00FAmero de certificado TTT')
,p_when_button_pressed=>wwv_flow_api.id(248440143947153817)
,p_associated_item=>wwv_flow_api.id(248440548499153817)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257020167189132118)
,p_validation_name=>'VALIDAR_PERMISO_CTP_NOT_NULL'
,p_validation_sequence=>190
,p_validation=>'P14_PERMISO_CTP'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar un archivo'
,p_when_button_pressed=>wwv_flow_api.id(248440143947153817)
,p_associated_item=>wwv_flow_api.id(248441316927153818)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248510503605558695)
,p_name=>'DAC_TIPO_HOSPEDAJE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248510935477558696)
,p_event_id=>wwv_flow_api.id(248510503605558695)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248511485773558696)
,p_event_id=>wwv_flow_api.id(248510503605558695)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Tipo_Hospedaje'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248524067238689414)
,p_name=>'DAC_MENSAJE'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_MENSAJE'
,p_condition_element=>'P14_MENSAJE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(257020325233132120)
,p_event_id=>wwv_flow_api.id(248524067238689414)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P14_RB_TIPOS_DECLARATORIAS'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248525853463731120)
,p_name=>'DAC_TIPO_GASTRONOMIA'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248526231262731120)
,p_event_id=>wwv_flow_api.id(248525853463731120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248526728872731120)
,p_event_id=>wwv_flow_api.id(248525853463731120)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Tipo_Gastronomia'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248537594986981027)
,p_name=>'DAC_TIPO_TRANSPORTE_ACUATICO'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'6'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248537979637981027)
,p_event_id=>wwv_flow_api.id(248537594986981027)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248538469332981028)
,p_event_id=>wwv_flow_api.id(248537594986981027)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Transporte_acuatico'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248540052196018577)
,p_name=>'DAC_TIPO_AGENCIA_VIAJES'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'4'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248540483079018578)
,p_event_id=>wwv_flow_api.id(248540052196018577)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248540993338018578)
,p_event_id=>wwv_flow_api.id(248540052196018577)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''agencia_viajes'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248544440379085499)
,p_name=>'DAC_TIPO_LINEAS_AEREAS'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'5'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248544833401085500)
,p_event_id=>wwv_flow_api.id(248544440379085499)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248545302981085500)
,p_event_id=>wwv_flow_api.id(248544440379085499)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''lineas_aereas'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248658309082458838)
,p_name=>'DAC_TIPO_ACT_TEMATICAS'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'7'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248658740011458854)
,p_event_id=>wwv_flow_api.id(248658309082458838)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248659233223458856)
,p_event_id=>wwv_flow_api.id(248658309082458838)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''act_tematicas'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248664106400533014)
,p_name=>'DAC_TIPO_RENT_A_CAR'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'8'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248664582568533015)
,p_event_id=>wwv_flow_api.id(248664106400533014)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248665053157533015)
,p_event_id=>wwv_flow_api.id(248664106400533014)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''rent_car'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248668271561610635)
,p_name=>'DAC_TIPO_TRANSPORTE_TERRESTRE'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'12'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248668662218610635)
,p_event_id=>wwv_flow_api.id(248668271561610635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248669113225610636)
,p_event_id=>wwv_flow_api.id(248668271561610635)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''Transporte_terrestre'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(248671367266667692)
,p_name=>'DAC_TIPO_MARINA'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_condition_element=>'P14_RB_TIPOS_DECLARATORIAS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'16'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248671798715667693)
,p_event_id=>wwv_flow_api.id(248671367266667692)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_attribute_02=>'P14_RB_TIPOS_DECLARATORIAS'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(248672264628667693)
,p_event_id=>wwv_flow_api.id(248671367266667692)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''marina'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(257020699562132123)
,p_name=>'DAC_SOLO_NUMEROS'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_FLOTILLA,P14_CERTIFICADO_TTT'
,p_bind_type=>'bind'
,p_bind_event_type=>'keydown'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(257020741632132124)
,p_event_id=>wwv_flow_api.id(257020699562132123)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validateNumber(event);'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248522617544620115)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_HOSPEDAJE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'    ',
'    if :P14_AUTORIZACION_ADI is not NULL',
'        then',
'            SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES ',
'			WHERE NAME = :P14_AUTORIZACION_ADI;',
'      ',
'            PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 2, vArchivo, NULL, NULL, ',
'			vNombreArchivo, NULL, :P14_ZONA_INDIGENA, :P14_TIPO_HOSPEDAJE, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'    end if;',
'     ',
'    if :P14_AUTORIZACION_ADI is NULL',
'        then',
'            PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 2, NULL, NULL, NULL, ',
'			NULL, NULL, :P14_ZONA_INDIGENA, :P14_TIPO_HOSPEDAJE, NULL, vMensaje_Retorno, vRetorno);',
'    end if;',
'          ',
'	if vMensaje_Retorno is not null and vRetorno = true',
'        then',
'            :P14_MENSAJE := ''S'';',
'    else',
'            :P14_MENSAJE := ''N'';',
'    end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248427358918153805)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248527123151735255)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_GASTRONOMIA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'',
'begin',
'    PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 3, NULL, NULL, NULL, NULL, NULL, NULL, ',
'		:P14_TIPO_GASTRONOMIA, NULL, vMensaje_Retorno, vRetorno);',
'    ',
'	if vMensaje_Retorno is not null and vRetorno = true',
'        then',
'            :P14_MENSAJE := ''S'';',
'    else',
'            :P14_MENSAJE := ''N'';',
'    end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248429257844153807)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248536575120933760)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_TRANS_ACUATICOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'	WHERE NAME = :P14_PERMISO_MOPT;',
'      ',
'    PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 6, vArchivo, :P14_APROBACION_CIMAT, NULL, ',
'	vNombreArchivo, NULL, NULL, :P14_TRANSPORTE_ACUATICO, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'                        ',
'    if vMensaje_Retorno is not null and vRetorno = true',
'        then',
'            :P14_MENSAJE := ''S'';',
'    else',
'            :P14_MENSAJE := ''N'';',
'    end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248430792659153808)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248541337215023414)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_AGENCIA_VIAJES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'	SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'	WHERE NAME = :P14_CERTIF_MEIC;',
'      ',
'	PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 4, vArchivo, NULL, NULL,',
'	vNombreArchivo, NULL, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'                        ',
'	if vMensaje_Retorno is not null and vRetorno = true ',
'		then',
'            :P14_MENSAJE := ''S'';',
'    else',
'            :P14_MENSAJE := ''N'';',
'    end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248434511253153812)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248545765683088000)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_LINEAS_AEREAS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'    WHERE NAME = :P14_CERTIF_CEA;',
'      ',
'    PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 5, vArchivo, NULL, NULL, ',
'	vNombreArchivo, NULL, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'    ',
'	if vMensaje_Retorno is not null and vRetorno = true',
'        then',
'			:P14_MENSAJE := ''S'';',
'    else',
'            :P14_MENSAJE := ''N'';',
'    end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248435663029153813)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248659618555463334)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_ACT_TEMATICAS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'    if :P14_AUTORIZACION_ADI_1 is not NULL then',
'            SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES ',
'			WHERE NAME = :P14_AUTORIZACION_ADI_1;',
'      ',
'            PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 7, vArchivo, NULL, NULL, ',
'			vNombreArchivo, NULL, :P14_ZONA_INDIGENA_1, :P14_ACT_TEMATICAS, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'    end if;',
'     ',
'    if :P14_AUTORIZACION_ADI_1 is NULL then',
'            PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 7, NULL, NULL, NULL,',
'            NULL, NULL, :P14_ZONA_INDIGENA_1, :P14_ACT_TEMATICAS, NULL, vMensaje_Retorno, vRetorno);',
'    end if;',
'              ',
'	if vMensaje_Retorno is not null and vRetorno = true then',
'            :P14_MENSAJE := ''S'';',
'    else',
'            :P14_MENSAJE := ''N'';',
'    end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248432643317153811)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248665440628535719)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_RENT_CAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'    ',
'     if :P14_CONTRATO is not NULL',
'         then',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P14_CONTRATO;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 8, vArchivo, NULL, :P14_FLOTILLA, ',
'                        vNombreArchivo, NULL, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'          end if;',
'     ',
'     if :P14_CONTRATO is NULL',
'         then',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 8, NULL, NULL, :P14_FLOTILLA,',
'                        NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'         end if;',
'     ',
'     if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P14_MENSAJE := ''S'';',
'             else',
'             :P14_MENSAJE := ''N'';',
'     end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248437865656153815)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248669506780616544)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_TRANS_TERRESTRE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'	SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'	WHERE NAME = :P14_PERMISO_CTP;',
'      ',
'    PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 12, vArchivo, NULL, NULL, ',
'	vNombreArchivo, :P14_CERTIFICADO_TTT, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'	',
'	if vMensaje_Retorno is not null and vRetorno = true then',
'        :P14_MENSAJE := ''S'';',
'    else',
'        :P14_MENSAJE := ''N'';',
'    end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248440143947153817)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248672608198670350)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_MARINA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vTipoArchivo VARCHAR2(255);',
'vNombreArchivo VARCHAR2(255);',
'',
'begin',
'             SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo, vTipoArchivo, vNombreArchivo FROM APEX_APPLICATION_TEMP_FILES',
'                 WHERE NAME = :P14_CONTRACTO_REGISTRO;',
'      ',
'             PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 16, vArchivo, NULL, NULL,',
'                        vNombreArchivo, NULL, NULL, NULL, vTipoArchivo, vMensaje_Retorno, vRetorno);',
'                        ',
'             if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P14_MENSAJE := ''S'';',
'             else',
'             :P14_MENSAJE := ''N'';',
'         end if;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248436722601153814)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248698579843617319)
,p_process_sequence=>100
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_FINALIZAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vTipo number;',
'',
'begin',
'',
'    if :P14_RB_TIPOS_DECLARATORIAS is not null then',
'    ',
'        CASE :P14_RB_TIPOS_DECLARATORIAS ',
'           WHEN ''9'' THEN PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'           WHEN ''11'' THEN PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'           WHEN ''13'' THEN PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'           WHEN ''14'' THEN PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'           WHEN ''15'' THEN PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'           WHEN ''17'' THEN PKG_DECLARATORIA.Insertar_Tipo_Declaratoria(:P14_ID_DECLARATORIA, 17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, vMensaje_Retorno, vRetorno);',
'           ELSE vTipo := 0;',
'        END CASE;',
'',
'        PKG_UTILIDADES.Notifica_Solicitud(1);',
'',
'        if vMensaje_Retorno is not null and vRetorno = true then',
'            :P14_MENSAJE := ''S'';',
'        else',
'            :P14_MENSAJE := ''N'';',
'        end if;',
'    end if;',
'end;'))
,p_process_error_message=>'Error al generar la solicitud, si el error persiste contacte al administrador del sistema.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248001045497937625)
,p_process_success_message=>unistr('La solicitud fue ingresada con \00E9xito')
);
wwv_flow_api.component_end;
end;
/
