prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>unistr('Solicitar Contrato Tur\00EDstico')
,p_alias=>'SOLICITAR-CONTRATO-TURISTICO'
,p_step_title=>unistr('Solicitar Contrato Tur\00EDstico')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240909104428'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20003208557367543)
,p_plug_name=>unistr('Solicitud de Contrato Tur\00EDstico')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Registro de datos para la solicitud de Contrato Tur\00EDstico</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12436900981635818)
,p_plug_name=>'Datos por ingresar'
,p_parent_plug_id=>wwv_flow_api.id(20003208557367543)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'CONTRATO_TURISTICO'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12441753230635814)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(12436900981635818)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Solicitud'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P8_ID_CONTRATO'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12441353856635814)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(12436900981635818)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P8_ID_CONTRATO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12440136699635815)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(12436900981635818)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_button_condition_type=>'NEVER'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(39640866927928513)
,p_branch_name=>'Go To Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P8_MENSAJE'
,p_branch_condition_text=>'S'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20002171298367532)
,p_name=>'P8_ID_CONTRATO'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(12436900981635818)
,p_item_source_plug_id=>wwv_flow_api.id(12436900981635818)
,p_source=>'ID_CONTRATO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20002204221367533)
,p_name=>'P8_ID_DECLARATORIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(12436900981635818)
,p_item_source_plug_id=>wwv_flow_api.id(12436900981635818)
,p_prompt=>unistr('ID de la Declaratoria Tur\00EDstica')
,p_source=>'ID_DECLARATORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20002522709367536)
,p_name=>'P8_ESTUDIO_ECONOMICO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(12436900981635818)
,p_item_source_plug_id=>wwv_flow_api.id(12436900981635818)
,p_prompt=>unistr('Estudio Econ\00F3mico')
,p_source=>'ESTUDIO_ECONOMICO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(20002641840367537)
,p_name=>'P8_PLANOS_CONST'
,p_source_data_type=>'BLOB'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(12436900981635818)
,p_item_source_plug_id=>wwv_flow_api.id(12436900981635818)
,p_prompt=>'Planos Constructivos'
,p_source=>'PLANOS_CONST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(25825414266693117)
,p_name=>'P8_PLAN_COMPRAS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(12436900981635818)
,p_prompt=>'Plan Compras'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(39640604115928511)
,p_name=>'P8_MENSAJE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(12436900981635818)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12442549184635813)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prc_AgregarContrato'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vEstudio_Econ BLOB;',
'vTipoArchivo_EE VARCHAR2(255);',
'vNombreArchivo_EE VARCHAR2(255);',
'vPlanos BLOB;',
'vTipoArchivo_P VARCHAR2(255);',
'vNombreArchivo_P VARCHAR2(255);',
'vId_Contrato NUMBER;',
'vPlan_Compras BLOB;',
'vTipoArchivo_PC VARCHAR2(255);',
'vNombreArchivo_PC VARCHAR2(255);',
'',
'begin',
'    if :P8_ESTUDIO_ECONOMICO is not NULL',
'        then',
'            SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vEstudio_Econ,vTipoArchivo_EE,vNombreArchivo_EE',
'            FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P8_ESTUDIO_ECONOMICO;',
'    if :P8_PLAN_COMPRAS is not NULL',
'        then ',
'            SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vPlan_Compras,vTipoArchivo_PC, vNombreArchivo_PC',
'            FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P8_PLAN_COMPRAS;',
'    if :P8_PLANOS_CONST is not NULL',
'        then',
'            SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vPlanos,vTipoArchivo_P, vNombreArchivo_P ',
'            FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P8_PLANOS_CONST;',
'                ',
'            PKG_CONTRATO.Insertar_Contrato(vId_Contrato, :P8_ID_DECLARATORIA, vEstudio_Econ,',
'                         vPlanos, vTipoArchivo_EE, vTipoArchivo_P, vPlan_Compras, vTipoArchivo_PC, vNombreArchivo_EE,',
'                         vNombreArchivo_P, vNombreArchivo_PC, :APP_USER, vMensaje_Retorno, vRetorno);',
'                         ',
'            :P8_ID_CONTRATO := vId_Contrato;',
'            ',
'            PKG_UTILIDADES.Notifica_Solicitud(2);',
'            ',
'         if vMensaje_Retorno is not null and vRetorno = true',
'         then',
'             :P8_MENSAJE := ''S'';',
'             else',
'             :P8_MENSAJE := ''N'';',
'         end if;',
'      end if;',
'     end if;',
'    end if;',
'end;'))
,p_process_error_message=>'Hubo un error en el registro'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(12441753230635814)
,p_process_success_message=>unistr('Registro ingresado con \00E9xito')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(12442170729635813)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(12436900981635818)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form AgregarContrato'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(39640779664928512)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>':P8_MENSAJE := null;'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
