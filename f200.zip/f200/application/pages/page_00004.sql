prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>'Modal: Registrar Usuario'
,p_alias=>'MODAL-REGISTRAR-USUARIO'
,p_page_mode=>'MODAL'
,p_step_title=>'Registrar Usuario al Sistema'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function validateNumber(event) {',
'  var keyCode = event.keyCode;',
unistr('  var excludedKeys = [8, 37, 39, 46];//Teclas extra que queremos que el campo acepte aparte de los n\00FAmeros, como el backspace'),
unistr('//Realizamos la validaci\00F3n de la tecla ingresada'),
'  if (!((keyCode >= 48 && keyCode <= 57) ||',
'      (keyCode >= 96 && keyCode <= 105) ||',
'      (excludedKeys.includes(keyCode)))) {',
'    event.preventDefault();',
'',
'  }',
'}',
'',
'function validateText(event) {',
'  var keyCode = event.keyCode;',
'  var excludedKeys = [8, 37, 39, 46, 32];',
'',
'  if (!((keyCode >= 65 && keyCode <= 90) ||',
'      (excludedKeys.includes(keyCode)))) {',
'    event.preventDefault();',
'',
'  }',
'} '))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20241017074206'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(64975931835009128)
,p_plug_name=>'Registro Usuario'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24136760250830149)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'USUARIOS_GESTION'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(64982563625009119)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24137721610830149)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(257818538593981250)
,p_plug_name=>'Ley 8668:'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:margin-top-sm'
,p_plug_template=>wwv_flow_api.id(24133046783830151)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('Estoy de acuerdo con el env\00EDo de informaci\00F3n a los medios previamente registrados, tomando en cuenta la Ley de Protecci\00F3n de Datos')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40546654196414058)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(64982563625009119)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(40478391812483210)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(64982563625009119)
,p_button_name=>'BTN_REGISTRO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Registrarme'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-check-circle-o'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40478517833483212)
,p_name=>'P4_TIPO_CEDULA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_item_source_plug_id=>wwv_flow_api.id(64975931835009128)
,p_prompt=>unistr('Tipo de Identificaci\00F3n')
,p_source=>'TIPO_CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Extranjero;Extranjero,Nacional;Nacional'
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40478971530483216)
,p_name=>'P4_EXTRANJERO'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_item_source_plug_id=>wwv_flow_api.id(64975931835009128)
,p_prompt=>'DIMEX/Pasaporte'
,p_placeholder=>'Sin guiones, ni espacios'
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('La identificaci\00F3n debe ser de 12 d\00EDgitos. El tipo de identificaci\00F3n f\00EDsica solo debe contener n\00FAmeros y letras, sin espacios ni guiones e iniciar con un valor diferente de 0.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40480241343483229)
,p_name=>'P4_RESPUESTA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40542405035414052)
,p_name=>'P4_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_item_source_plug_id=>wwv_flow_api.id(64975931835009128)
,p_prompt=>unistr('N\00B0 de Identificaci\00F3n')
,p_placeholder=>'Sin guiones, ni espacios'
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('La identificaci\00F3n debe ser de 9 d\00EDgitos. El tipo de identificaci\00F3n f\00EDsica solo debe contener n\00FAmeros e iniciar con un valor diferente de 0')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40542765605414054)
,p_name=>'P4_NOMBRE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_item_source_plug_id=>wwv_flow_api.id(64975931835009128)
,p_prompt=>'Nombre'
,p_source=>'NOMBRE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40543182264414054)
,p_name=>'P4_PAPELLIDO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_item_source_plug_id=>wwv_flow_api.id(64975931835009128)
,p_prompt=>'Primer apellido'
,p_source=>'PAPELLIDO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40543597299414054)
,p_name=>'P4_SAPELLIDO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_item_source_plug_id=>wwv_flow_api.id(64975931835009128)
,p_prompt=>'Segundo apellido'
,p_source=>'SAPELLIDO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40543905018414055)
,p_name=>'P4_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_item_source_plug_id=>wwv_flow_api.id(64975931835009128)
,p_prompt=>'Correo de notificaciones'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'EMAIL'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(40544353979414055)
,p_name=>'P4_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(64975931835009128)
,p_item_source_plug_id=>wwv_flow_api.id(64975931835009128)
,p_prompt=>unistr('Tel\00E9fono')
,p_placeholder=>'Sin guiones, ni espacios'
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(24225373811830116)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(258083766245976228)
,p_validation_name=>'VALIDAR_NOMBRE_NOT_NULL'
,p_validation_sequence=>30
,p_validation=>'P4_NOMBRE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar un nombre'
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40542765605414054)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257818267029981247)
,p_validation_name=>'VALIDAR_PAPELLIDO_NOT_NULL'
,p_validation_sequence=>40
,p_validation=>'P4_PAPELLIDO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar el primer apellido'
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40543182264414054)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257818330488981248)
,p_validation_name=>'VALIDAR_SAPELLIDO_NOT_NULL'
,p_validation_sequence=>50
,p_validation=>'P4_SAPELLIDO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe ingresar el segundo apellido'
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40543597299414054)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(257818445944981249)
,p_validation_name=>'VALIDAR_TELEFONO_NOT_NULL'
,p_validation_sequence=>60
,p_validation=>'P4_TELEFONO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el n\00FAmero de tel\00E9fono')
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40544353979414055)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(258084027705979195)
,p_validation_name=>'VALIDAR_TIPO_IDENTIFICACION_NOT_NULL'
,p_validation_sequence=>70
,p_validation=>'P4_TIPO_CEDULA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar una opci\00F3n')
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40478517833483212)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(258084364156980644)
,p_validation_name=>'VAL_CEDULA_EXTRANJERO_12_DIGITOS'
,p_validation_sequence=>80
,p_validation=>'P4_EXTRANJERO'
,p_validation2=>'^[1-9A-Za-z]\w*{12}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>unistr('La identificaci\00F3n debe ser de 12 d\00EDgitos. El tipo de identificaci\00F3n f\00EDsica solo debe contener n\00FAmeros y letras, sin espacios ni guiones')
,p_always_execute=>'Y'
,p_validation_condition=>'P4_TIPO_CEDULA'
,p_validation_condition2=>'Extranjero'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40478971530483216)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(258084641284981486)
,p_validation_name=>'VAL_CEDULA_EXTRANJERO_NOT_NULL'
,p_validation_sequence=>90
,p_validation=>'P4_EXTRANJERO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el N\00B0 de Identificaci\00F3n')
,p_validation_condition=>'P6_TIPO_IDENTIFICACION'
,p_validation_condition2=>'Extranjero'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(40478971530483216)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(258084977986982622)
,p_validation_name=>'VAL_CEDULA_NACIONAL_9_DIGITOS'
,p_validation_sequence=>100
,p_validation=>'P4_CEDULA'
,p_validation2=>'^[1-9]\d{8}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>unistr('La identificaci\00F3n debe ser de 9 d\00EDgitos y no puede iniciar con 0')
,p_always_execute=>'Y'
,p_validation_condition=>'P4_TIPO_CEDULA'
,p_validation_condition2=>'Nacional'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40542405035414052)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(258085232448983551)
,p_validation_name=>'VAL_CEDULA_NACIONAL_NOT_NULL'
,p_validation_sequence=>110
,p_validation=>'P4_CEDULA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el N\00B0 de Identificaci\00F3n')
,p_validation_condition=>'P6_TIPO_IDENTIFICACION'
,p_validation_condition2=>'Nacional'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40542405035414052)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(258085534556985192)
,p_validation_name=>'VALIDAR_CORREO_FORMAT'
,p_validation_sequence=>120
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P4_CORREO,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'')'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Por favor, ingrese un correo v\00E1lido')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(40478391812483210)
,p_associated_item=>wwv_flow_api.id(40543905018414055)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(40550226469414083)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(40546654196414058)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40550719416414085)
,p_event_id=>wwv_flow_api.id(40550226469414083)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(40479032227483217)
,p_name=>'DAC_NACIONAL'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_TIPO_CEDULA'
,p_condition_element=>'P4_TIPO_CEDULA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Nacional'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40479190459483218)
,p_event_id=>wwv_flow_api.id(40479032227483217)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_CEDULA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40479232716483219)
,p_event_id=>wwv_flow_api.id(40479032227483217)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_CEDULA'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(40479334709483220)
,p_name=>'DAC_EXTRANJERO'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_TIPO_CEDULA'
,p_condition_element=>'P4_TIPO_CEDULA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Extranjero'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40479480024483221)
,p_event_id=>wwv_flow_api.id(40479334709483220)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_EXTRANJERO'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40479542670483222)
,p_event_id=>wwv_flow_api.id(40479334709483220)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_EXTRANJERO'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250928039692204471)
,p_name=>'VAL_SOLO_LETRAS'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_NOMBRE,P4_PAPELLIDO,P4_SAPELLIDO'
,p_bind_type=>'bind'
,p_bind_event_type=>'keydown'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250928468604204472)
,p_event_id=>wwv_flow_api.id(250928039692204471)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validateText(event);'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(258099148382106922)
,p_name=>'VAL_SOLO_NUM'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_CEDULA,P4_TELEFONO'
,p_bind_type=>'bind'
,p_bind_event_type=>'keydown'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(258099518697106928)
,p_event_id=>wwv_flow_api.id(258099148382106922)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validateNumber(event);'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40478434613483211)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prc_AgregarUsuario'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'',
'begin',
'   if :P4_CEDULA is not null',
'    then',
'        PKG_USUARIOS.Insertar_Usuario(:P4_NOMBRE, :P4_PAPELLIDO, :P4_SAPELLIDO, :P4_TIPO_CEDULA, :P4_CEDULA, :P4_CORREO,',
'                                     :P4_TELEFONO, :P4_CEDULA, vMensaje_Retorno, vRetorno);',
'    end if;',
'    ',
'    if :P4_EXTRANJERO is not null',
'    then',
'        PKG_USUARIOS.Insertar_Usuario(:P4_NOMBRE, :P4_PAPELLIDO, :P4_SAPELLIDO, :P4_TIPO_CEDULA, :P4_EXTRANJERO, :P4_CORREO,',
'                                     :P4_TELEFONO, :P4_EXTRANJERO, vMensaje_Retorno, vRetorno);',
'    end if;',
' ',
'   if vMensaje_Retorno is not NULL-- and vRetorno = true',
'         then',
'             :P4_RESPUESTA := vMensaje_Retorno;',
'             else',
'             :P4_RESPUESTA := vMensaje_Retorno;',
'         end if;',
'         ',
'end;'))
,p_process_error_message=>'Error al crear el usuario'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(40478391812483210)
,p_process_success_message=>unistr('Registro Exitoso! Los datos de sesi\00F3n fueron enviados a su correo electr\00F3nico')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40549825563414083)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(40546654196414058)
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40545519178414056)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(64975931835009128)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form PerfilUsuario'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40480967969483236)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_Respuesta'
,p_process_sql_clob=>':P4_RESPUESTA := null;'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P4_NOMBRE'
,p_process_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.component_end;
end;
/
