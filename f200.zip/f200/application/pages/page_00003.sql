prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>'Modal: Perfil de Usuario'
,p_alias=>'MODAL-PERFIL-USUARIO'
,p_page_mode=>'MODAL'
,p_step_title=>'Perfil de Usuario'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240919114937'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24434088687595100)
,p_plug_name=>'Perfil de Usuario'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24136760250830149)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NOMBRE,',
'       PAPELLIDO,',
'       SAPELLIDO,',
'       TIPO_CEDULA,',
'       CEDULA,',
'       CORREO,',
'       TELEFONO',
'  from USUARIOS_GESTION'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(24441154840595090)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(24434088687595100)
,p_button_name=>'BTN_CANCELAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(42185498839462601)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(24434088687595100)
,p_button_name=>'BTN_ACTUALIZAR_USUARIO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--simple:t-Button--iconRight:t-Button--hoverIconPush:t-Button--padTop'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Actualizar'
,p_button_position=>'BELOW_BOX'
,p_icon_css_classes=>'fa-save-as'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250037098591469833)
,p_name=>'P3_NOMBRE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(24434088687595100)
,p_item_source_plug_id=>wwv_flow_api.id(24434088687595100)
,p_prompt=>'Nombre'
,p_source=>'NOMBRE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250037147292469834)
,p_name=>'P3_PAPELLIDO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(24434088687595100)
,p_item_source_plug_id=>wwv_flow_api.id(24434088687595100)
,p_prompt=>unistr('1\00B0 Apellido')
,p_source=>'PAPELLIDO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250037230869469835)
,p_name=>'P3_SAPELLIDO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(24434088687595100)
,p_item_source_plug_id=>wwv_flow_api.id(24434088687595100)
,p_prompt=>unistr('2\00B0 Apellido')
,p_source=>'SAPELLIDO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250037331600469836)
,p_name=>'P3_TIPO_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(24434088687595100)
,p_item_source_plug_id=>wwv_flow_api.id(24434088687595100)
,p_prompt=>unistr('Tipo Identificaci\00F3n')
,p_source=>'TIPO_CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250037408787469837)
,p_name=>'P3_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(24434088687595100)
,p_item_source_plug_id=>wwv_flow_api.id(24434088687595100)
,p_prompt=>unistr('N\00B0 de Identificaci\00F3n')
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250037573095469838)
,p_name=>'P3_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(24434088687595100)
,p_item_source_plug_id=>wwv_flow_api.id(24434088687595100)
,p_prompt=>'Correo'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(250037603391469839)
,p_name=>'P3_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(24434088687595100)
,p_item_source_plug_id=>wwv_flow_api.id(24434088687595100)
,p_prompt=>unistr('N\00B0 de Telefono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(24441268692595090)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(24441154840595090)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(24442085091595089)
,p_event_id=>wwv_flow_api.id(24441268692595090)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(24444371435595086)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(24434088687595100)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form PerfilUsuario'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(24444713621595086)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40482312742483250)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZAR_USUARIO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    vMensaje_Retorno VARCHAR2(355);',
'    vRetorno boolean;',
'begin',
'    PKG_USUARIOS.Actualizar_Usuario(:P3_NOMBRE, :P3_PAPELLIDO, :P3_SAPELLIDO, :P3_TIPO_CEDULA, :P3_CEDULA, :P3_CORREO, :P3_TELEFONO, vMensaje_Retorno, vRetorno);',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(42185498839462601)
,p_process_success_message=>unistr('Sus datos han sido actualizados con \00E9xito')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(24443951813595086)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(24434088687595100)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form PerfilUsuario'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(11645947702192613)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prc_DatosUsuario'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    vnombre VARCHAR2(30);',
'    vpapellido VARCHAR2(30);',
'    vsapellido VARCHAR2(30);',
'    vtipocedula VARCHAR2(20);',
'    vcorreo VARCHAR2(60);',
'    vtelefono VARCHAR2(60);   ',
'    ',
'    cursor c_datosUsuario is',
'        SELECT NOMBRE, PAPELLIDO, SAPELLIDO, TIPO_CEDULA, CORREO, TELEFONO from USUARIOS_GESTION where UPPER(usuario) = :APP_USER;',
'begin',
'    open c_datosUsuario;',
'    fetch c_datosUsuario into vnombre, vpapellido, vsapellido, vtipocedula, vcorreo, vtelefono;',
'    close c_datosUsuario;',
'   ',
'   :P3_NOMBRE := vnombre;',
'   :P3_PAPELLIDO := vpapellido;',
'   :P3_SAPELLIDO := vsapellido;',
'   :P3_TIPO_CEDULA := vtipocedula;',
'   :P3_CEDULA := :APP_USER;',
'   :P3_CORREO := vcorreo;',
'   :P3_TELEFONO := vtelefono;',
'   ',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
