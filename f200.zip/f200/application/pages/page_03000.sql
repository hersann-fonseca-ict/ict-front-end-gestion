prompt --application/pages/page_03000
begin
--   Manifest
--     PAGE: 03000
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>3000
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>'Prueba | Legacy'
,p_alias=>'PRUEBA'
,p_step_title=>'prueba'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240909110608'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(180125560480530405)
,p_plug_name=>'New'
,p_region_name=>'ID_MODAL'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(24156616464830141)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(353293862895907722)
,p_plug_name=>'Seguimiento'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24162260119830139)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT e.id_empresa, ',
'      e.nombre_solicitante, ',
'      e.razon_social, ',
'      e.nombre_comercial, ',
'      e.correo, ',
'      e.telefono, ',
'      dt.id_declaratoria, ',
'      dt.fecha_registro, ',
'      dt.id_analista, ',
'      dt.estadodt, ',
'      dt.estadodt estado2,',
'      ''Responder'' responder,',
'      case dt.estadodt',
'           when 1 then ''''',
'           when 2 then ''''',
'           when 3 then ''''',
'           when 4 then ''far fa-check-circle''',
'           when 5 then ''''',
'           when 6 then ''''',
'           when 7 then ''''',
'           when 8 then ''''',
'       end as icon_class,       ',
'       case dt.estadodt',
'           when 1 then ''''',
'           when 2 then ''''',
'           when 3 then ''''',
'           when 4 then ''#7AFF33''',
'           when 5 then ''''',
'           when 6 then ''''',
'           when 7 then ''''',
'           when 8 then ''''',
'       end as color_class,',
'       case dt.estadodt',
'           when 1 then ''#''',
'           when 2 then ''#''',
'           when 3 then ''#''',
'           when 4 then --''<a href="f?p=&APP_ID.:10:&SESSION."></a>''',
'           ''javascript:$s("f?p=&APP_ID.:10");javascript:openModal("ID_MODAL"); $("#ID_MODAL").trigger("apexrefresh");''',
'           when 5 then ''#''',
'           when 6 then ''#''',
'           when 7 then ''#''',
'           when 8 then ''#''',
'       end as link',
'FROM empresa e, declaratoria_turistica dt ',
'   WHERE e.id_empresa = dt.id_empresa ',
'    AND      e.cedula_solicitante = ''114460817''',
'  '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Seguimiento'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(353294253708907722)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,:P10_ID_EMPRESA,P10_ID_DECLARATORIA:\#ID_EMPRESA#\,\#ID_DECLARATORIA#\'
,p_detail_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS#" style="color: #COLOR_CLASS#;">',
'    <spam class="visuallyhidden">#ESTADODT#</spam>',
'',
''))
,p_detail_link_condition_type=>'NEVER'
,p_owner=>'ADRIANA.RUBIO'
,p_internal_uid=>353294253708907722
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(173488417775460614)
,p_db_column_name=>'RESPONDER'
,p_display_order=>10
,p_column_identifier=>'P'
,p_column_label=>'Responder'
,p_column_link=>'#LINK#'
,p_column_linktext=>'#RESPONDER#'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180119039650490105)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Id Empresa'
,p_column_type=>'NUMBER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>':ESTADODT'
,p_display_condition2=>'4'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180121417551490108)
,p_db_column_name=>'ID_DECLARATORIA'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Id Declaratoria'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180119484538490106)
,p_db_column_name=>'NOMBRE_SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Nombre Solicitante'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180119841604490106)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Razon Social'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180120259219490107)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Nombre Comercial'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180120600281490107)
,p_db_column_name=>'CORREO'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180121053022490108)
,p_db_column_name=>'TELEFONO'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>unistr('Tel\00E9fono')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180121821791490109)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Fecha Registro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180122230792490109)
,p_db_column_name=>'ID_ANALISTA'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Analista Asignado'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(173482878494144833)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180122699064490110)
,p_db_column_name=>'ESTADODT'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>unistr('Estado del Tr\00E1mite')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_api.id(173483067859153628)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180125120306530401)
,p_db_column_name=>'ICON_CLASS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Icon Class'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180125264359530402)
,p_db_column_name=>'COLOR_CLASS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Color Class'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180125411580530404)
,p_db_column_name=>'LINK'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Link'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(180125719437530407)
,p_db_column_name=>'ESTADO2'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Estado2'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(353300616454914004)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1801234'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RESPONDER:NOMBRE_SOLICITANTE:RAZON_SOCIAL:NOMBRE_COMERCIAL:CORREO:TELEFONO:FECHA_REGISTRO:ID_ANALISTA:ESTADODT:'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(180125846300530408)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(180125560480530405)
,p_button_name=>'New'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'New'
,p_button_position=>'BODY'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180125651298530406)
,p_name=>'P3000_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(180125560480530405)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(180123833692490135)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(353293862895907722)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(180124380449490138)
,p_event_id=>wwv_flow_api.id(180123833692490135)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(353293862895907722)
);
wwv_flow_api.component_end;
end;
/
