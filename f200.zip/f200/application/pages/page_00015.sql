prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>15
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>unistr('Solictar Declaratoria Tur\00EDstica Jur\00EDdica')
,p_alias=>'SOLICITAR-DT-JURIDICA'
,p_step_title=>unistr('Solictar Declaratoria Tur\00EDstica Jur\00EDdica')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function validateNumber(event) {',
'  var keyCode = event.keyCode;',
unistr('  var excludedKeys = [8, 37, 39, 46];//Teclas extra que queremos que el campo acepte aparte de los n\00FAmeros, como el backspace'),
unistr('  //Realizamos la validaci\00F3n de la tecla ingresada'),
'  if (!((keyCode >= 48 && keyCode <= 57) ||',
'      (keyCode >= 96 && keyCode <= 105) ||',
'      (excludedKeys.includes(keyCode)))) {',
'    event.preventDefault();',
'  }',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240916140339'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(248709597169696770)
,p_plug_name=>'Datos Empresa'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(24174565993830135)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(248708492451696745)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(24203433356830125)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Registro de datos para la solicitud de Declaratoria Tur\00EDstica</h3></center>')))
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(496828771418094292)
,p_plug_name=>'Datos de la empresa'
,p_parent_plug_id=>wwv_flow_api.id(248709597169696770)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(24136964380830149)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248711395519696778)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(248709597169696770)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(248711604391696778)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(248709597169696770)
,p_button_name=>'SIGUIENTE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(24226354499830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(248712336784696785)
,p_branch_name=>'Go To Page 16'
,p_branch_action=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::P16_ID_EMPRESA:&P15_ID_EMPRESA.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(248711604391696778)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248837528176156691)
,p_name=>'P15_ID_EMPRESA'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_source=>'ID_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248839588504156699)
,p_name=>'P15_NOMBRE_COMERCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Nombre Comercial'
,p_source=>'NOMBRE_COMERCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24224895246830117)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248839994027156700)
,p_name=>'P15_TELEFONO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>unistr('Tel\00E9fono')
,p_source=>'TELEFONO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248840316613156701)
,p_name=>'P15_CORREO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Correo para notificaciones'
,p_source=>'CORREO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>60
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248840750026156701)
,p_name=>'P15_ID_PROVINCIA'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Provincia'
,p_source=>'ID_PROVINCIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT descripcion, id FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248841194687156702)
,p_name=>'P15_ID_CANTON'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>unistr('Cant\00F3n')
,p_source=>'ID_CANTON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id from CANTONES@consulta_ictx where prov_id = :P15_ID_PROVINCIA'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P15_ID_PROVINCIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248841581942156703)
,p_name=>'P15_ID_DISTRITO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>'Distrito'
,p_source=>'ID_DISTRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id from DISTRITOS@consulta_ictx WHERE prov_id = :P15_ID_PROVINCIA AND canton_id = :P15_ID_CANTON'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P15_ID_CANTON,P15_ID_PROVINCIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248841992514156704)
,p_name=>'P15_DIRECCION_EXACTA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_item_source_plug_id=>wwv_flow_api.id(11648756283192641)
,p_prompt=>unistr('Direcci\00F3n Exacta')
,p_source=>'DIRECCION_EXACTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>100
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(24225200018830116)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248842390897156704)
,p_name=>'P15_MENSAJE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(248848593692183255)
,p_name=>'P15_RAZON_SOCIAL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(496828771418094292)
,p_prompt=>unistr('Raz\00F3n Social')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_api.id(24224895246830117)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248853595971205941)
,p_validation_name=>'VALIDAR_TELEFONO_NOT_NULL'
,p_validation_sequence=>10
,p_validation=>'P15_TELEFONO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar un n\00FAmero de tel\00E9fono')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(248711604391696778)
,p_associated_item=>wwv_flow_api.id(248839994027156700)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248853852810207594)
,p_validation_name=>'VALIDAR_CORREO_FORMAT'
,p_validation_sequence=>20
,p_validation=>'select 1 from dual where not regexp_like (nvl(:P15_CORREO,''n/a''), ''^[A-Za-z]+[A-Za-z0-9.]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$'')'
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>unistr('Por favor, ingrese un correo v\00E1lido')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(248711604391696778)
,p_associated_item=>wwv_flow_api.id(248840316613156701)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248854117377209399)
,p_validation_name=>'VALIDAR_CORREO_NOT_NULL'
,p_validation_sequence=>30
,p_validation=>'P15_CORREO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar un correo electr\00F3nico')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(248711604391696778)
,p_associated_item=>wwv_flow_api.id(248840316613156701)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248854476515210683)
,p_validation_name=>'VALIDAR_ID_PROVINCIA_NOT_NULL'
,p_validation_sequence=>40
,p_validation=>'P15_ID_PROVINCIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar una provincia'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(248711604391696778)
,p_associated_item=>wwv_flow_api.id(248840750026156701)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248854708619211934)
,p_validation_name=>'VALIDAR_ID_CANTON_NOT_NULL'
,p_validation_sequence=>50
,p_validation=>'P15_ID_CANTON'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe seleccionar un cant\00F3n')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(248711604391696778)
,p_associated_item=>wwv_flow_api.id(248841194687156702)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248855038241213127)
,p_validation_name=>'VALIDAR_ID_DISTRITO_NOT_NULL'
,p_validation_sequence=>60
,p_validation=>'P15_ID_DISTRITO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un distrito'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(248711604391696778)
,p_associated_item=>wwv_flow_api.id(248841581942156703)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(248855397454214678)
,p_validation_name=>'VALIDAR_DIRECCION_EXACTA_NOT_NULL'
,p_validation_sequence=>70
,p_validation=>'P15_DIRECCION_EXACTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar la direcci\00F3n exacta')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_api.id(248711604391696778)
,p_associated_item=>wwv_flow_api.id(248841992514156704)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(250920528005000888)
,p_name=>'VAL_SOLO_NUM'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P15_TELEFONO,P15_RAZON_SOCIAL'
,p_bind_type=>'bind'
,p_bind_event_type=>'keydown'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(250920981824000889)
,p_event_id=>wwv_flow_api.id(250920528005000888)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validateNumber(event);'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(248857663125265654)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTAR_EMPRESA_JURIDICA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'    vcedula VARCHAR2(30);',
'',
'begin',
'',
'-- Identificar la cedula del usuario logueado',
'    vcedula := PKG_USUARIOS.Consulta_usuario(:APP_USER);',
'',
'-- INSERTAMOS LA EMPRESA',
'    :P15_ID_EMPRESA := PKG_DECLARATORIA.Insertar_Empresa(:P15_ID_PROVINCIA, NULL, NULL, :P15_TELEFONO, :P15_CORREO,',
unistr('	:P15_DIRECCION_EXACTA, :P15_ID_CANTON, :P15_ID_DISTRITO, ''Jur\00EDdica'', NULL, :P15_RAZON_SOCIAL, :P15_NOMBRE_COMERCIAL, vcedula);'),
'end;'))
,p_process_error_message=>'Error al guardar los datos de empresa, si el error persiste contacte al administrador del sistema.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(248711604391696778)
,p_process_success_message=>unistr('Los datos de la empresa fueron guardados con \00E9xito')
);
wwv_flow_api.component_end;
end;
/
