prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>7853362961052754
,p_default_application_id=>200
,p_default_id_offset=>12240694068067115
,p_default_owner=>'DESA_GES'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(24248819033830104)
,p_name=>'Recuperar Clave'
,p_alias=>'RECUPERAR-CLAVE'
,p_page_mode=>'MODAL'
,p_step_title=>'Recuperar Clave'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'HERSANN.FONSECA'
,p_last_upd_yyyymmddhh24miss=>'20240909103708'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(23886189951259723)
,p_plug_name=>'Recuperar Clave'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(24164170035830138)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23886294643259725)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(23886189951259723)
,p_button_name=>'BTN_ENVIARCLAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(24226266547830116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar por correo'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(23886291060259724)
,p_name=>'P2_USUARIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(23886189951259723)
,p_prompt=>unistr('C\00E9dula')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(24225104457830116)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(40481676526483243)
,p_name=>'DAC_Respuesta'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_RESPUESTA'
,p_condition_element=>'P2_RESPUESTA'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40481764443483244)
,p_event_id=>wwv_flow_api.id(40481676526483243)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_MENSAJE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(40481834742483245)
,p_event_id=>wwv_flow_api.id(40481676526483243)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_MENSAJE'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(40480776553483234)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prc_RecuperarClave'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    PKG_USUARIOS.Recuperar_Clave(:P2_USUARIO);',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(23886294643259725)
,p_process_success_message=>unistr('Su clave ha sido enviada a su correo electr\00F3nico')
);
wwv_flow_api.component_end;
end;
/
